#ifndef API_H
#define API_H

#include "led.h"

/* Definition of the voltage range */
#define RANGE_ARRAY 	14,	\
			27,	\
			54,	\
			82,	\
			110,	\
			136,	\
			164,	\
			192,	\
			220,	\
			247,	\
			274,	\
			302	
			
			
/* Public global functions */
void led_init(void);
void turn_off_leds (void);
int range_choose(int data);
void led_on(int n);
void led_select(int a);

#endif