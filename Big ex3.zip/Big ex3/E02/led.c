#pragma sfr
#include "r_macro.h"  /* System macro and standard type definition */
#include "api.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "adc.h"      /* ADC driver interface */
#include "timer.h"
#include "led.h"




/******************************************************************************
* Function Name: led_select
* Description  : select which led to be turned on
* Arguments    : the led to be turned on
* Return Value : none
******************************************************************************/
void led_select(int a)
{
	switch (a)
	{
	case 0:
		LED0=LED_ON;
		break;
	case 1:
		LED1=LED_ON;
		break;
	case 2:
		LED2=LED_ON;
		break;
	case 3:
		LED3=LED_ON;
		break;
	case 4:	
		LED4=LED_ON;
		break;
	case 5:
		LED5=LED_ON;
		break;
	case 6:
		LED6=LED_ON;
		break;
	case 7:
		LED7=LED_ON;
		break;
	case 8:
		LED8=LED_ON;
		break;
	case 9:
		LED9=LED_ON;
		break;
	case 10:
		LED10=LED_ON;
		break;
	case 11:
		LED11=LED_ON;
		break;
	}
}

/******************************************************************************
* Function Name: range_choose
* Description  : Choose the number of leds to be on acording to voltage ranges
* Arguments    : int data - voltage data to choose voltage range
* Return Value : int - return the number of leds to be turned on
******************************************************************************/
int range_choose(int data)
{
	int range_array[]={RANGE_ARRAY};
	int n=0;
	int i;

	for (i=0;i<12;i++)
	{
		if(data>range_array[i])
		n++;
	}
	return n;
}

/******************************************************************************
* Function Name: turn_off_leds
* Description  : turn off all leds
* Arguments    : none
* Return Value : none
******************************************************************************/
void turn_off_leds (void)
{
	PORT4	|=0x3C;
	PORT6	|=0xFC;
	PORT10	|=0x02;
	PORT15	|=0x04;
}

/******************************************************************************
* Function Name: led_on
* Description  : turn on the number of leds which have been choosen
* Arguments    : int n - number of leds to be turned on
* Return Value : none
******************************************************************************/
void led_on(int n)
{
	int i;
	turn_off_leds();
	for(i=0;i<n;i++)
	led_select(i);
}

/******************************************************************************
* Function Name: led_init
* Description  : initialize leds as output pin
* Arguments    : none
* Return Value : none
******************************************************************************/
void led_init (void)
{
	ADPC =1;
	PORT_MODE4 &= 0xC3;
	PORT_MODE6 &= 0x03;
	PORT_MODE10 &= 0xFD;
	PORT_MODE15 &= 0xFB;
}


