#ifndef LED_H
#define LED_H

#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */

/* Definition of led ports mode */
#define PORT_MODE4 *(volatile unsigned char *)0XFFF24
#define PORT_MODE6 *(volatile unsigned char *)0xFFF26
#define PORT_MODE10 *(volatile unsigned char *)0xFFF2A
#define PORT_MODE15 *(volatile unsigned char *)0xFFF2F

/* Definition of led ports */
#define PORT4 *(volatile unsigned char *)0xFFF04
#define PORT6 *(volatile unsigned char *)0xFFF06
#define PORT10 *(volatile unsigned char *)0xFFF0A
#define PORT15 *(volatile unsigned char *)0xFFF0F

#define LED_ON	0

/* Definition of macro leds */
#define LED0	P6_bit.no2
#define LED1	P4_bit.no2
#define LED2	P6_bit.no3
#define LED3	P4_bit.no3
#define LED4	P6_bit.no4
#define LED5	P4_bit.no4
#define LED6	P6_bit.no5
#define LED7	P4_bit.no5
#define LED8	P6_bit.no6
#define LED9	P15_bit.no2
#define LED10	P6_bit.no7
#define LED11	P10_bit.no1

#endif