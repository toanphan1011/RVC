/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for main function.
* Creation Date: 11-Sep-15
******************************************************************************/

/******************************************************************************
Includes 
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "adc.h"      /* ADC driver interface */
#include "timer.h"
#include "api.h"

#define Vref 3.3

/******************************************************************************
Private global variables and functions
******************************************************************************/
/* Declare a variable to contain analog data */
int data=0;

/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;

uint8_t g_time_update_flag=0;

/* Declare a variable for Analog input voltage */
volatile float temp_voltage = 0;
volatile float analog_voltage = 0;

/* Declare a variable for noise voltage */
float noise;

/* Declare a variable to compare differences between  previous voltage and temporary voltage */
float diff;

/* Private global functions */
void LCD_Reset(void);
int voltage_record(uint16_t gADC_Result);
void user_main_init(void);
void display_lcd (int data);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	
	/* Declare a variable for number of leds */
	int number_of_leds=0;
	
	/* main initialization */
	user_main_init();
	
	/* Main loop - Infinite loop */
	while (1U)
	{
	    if (g_time_update_flag == 20)
	    {
		/* Start an A/D conversion */
		ADC_Start();
		
		/* Wait for the A/D conversion to complete */
		while(Adc_Status != ADC_DONE);
		
		/* Clear ADC flag */
		Adc_Status = 0;
		
		/* Shift the ADC result contained in the 16-bit ADCR register */
		gADC_Result = ADCR;
		
		/* Calculate and record voltage */
		data = voltage_record(gADC_Result);
		
		/* Choose the number of leds to be turned on based on range of voltage*/
		number_of_leds = range_choose(data);
		
		/* Turn on the led which is specified */
		led_on(number_of_leds);
		
		/* Display the voltage on lcd screen*/
		display_lcd(data);
		
		/* Update g_time_update_flag back to 0 */
		g_time_update_flag=0;
	    }
	    else
	    {
                /* Do nothing */
	    }
	}
	
	/* Stop timer interval */
	timer_stop();
}

/******************************************************************************
* Function Name: user_main_init
* Description  : main initialize function
* Arguments    : none
* Return Value : none
******************************************************************************/
void user_main_init(void)
{
	/* Initialize leds to be output pin */
	led_init();
	
	/* Turn off all leds after initialization */
	turn_off_leds();
	
	/* Initialize and start timer interval module */
	timer_init();
	timer_start();
	
	/* Initialize ADC module */
	noise=(3.3*1.2)/1024;
	
	/* Initialize ADC module */
        ADC_Create();
	ADC_Set_OperationOn();
	
	/* Enable interrupt */
	EI();
	LCD_Reset();
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	/* Initialize LCD driver */
	InitialiseLCD();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Display information on the debug LCD.*/
	DisplayLCD(LCD_LINE1, (uint8_t *)"Voltage VR1 ");
}

/******************************************************************************
* Function Name: LCD_Reset
* Description  : reset LCD
* Arguments    : none
* Return Value : none
******************************************************************************/
void LCD_Reset(void)
{
    int i = 0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }
    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }
    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}

/******************************************************************************
* Function Name: voltage_record
* Description  : record voltage analog value to digital integer value
* Arguments    : uint16_t gADC_Result - ADC result voltage
* Return Value : int - integer data value
******************************************************************************/
int voltage_record(uint16_t gADC_Result)
{
	int int_value;
	
	/* Convert ADC result to temporary voltage */
	temp_voltage = ((float)gADC_Result/64);
	temp_voltage = (temp_voltage * Vref) / 1024;
	
	/* Compare the different value between the previous voltage and the temporary voltage */
	diff=((analog_voltage > temp_voltage) ? (analog_voltage-temp_voltage) : (temp_voltage-analog_voltage));
	
	/* If the different is bigger than conversion error noise than it will accept the new voltage */
	if (diff >= noise)
	analog_voltage = temp_voltage;
	
	/* Change the voltage value to integer value and return the result */
	int_value = (analog_voltage - (float)(int)analog_voltage) * 100;
	return (int_value+((float)(int)analog_voltage * 100));
}

/******************************************************************************
* Function Name: display_lcd
* Description  : display voltage value to LCD
* Arguments    : int data - voltage data to be displayed
* Return Value : none
******************************************************************************/
void display_lcd (int data)
{
	char str[5];
	
	str[0] = data/100 + '0';
	str[1] = '.';
	str[2] = (data%100)/10 + '0';
	str[3] = (data%100)%10 + '0';
	str[4] = 'V';
	str[5] = '\0';
	
	/* Display the contents of the local string lcd_buffer */
	DisplayLCD(LCD_LINE2, (const uint8_t*)str);
}
/******************************************************************************
End of file
******************************************************************************/
