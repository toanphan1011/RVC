/*******************************************************************************
 *
 * PURPOSE
 *   RIVP Reference Application for RIVP VIN Sub Window Manger Wrapper Public Defines
 *
 * AUTHOR
 *   Renesas Electronics Corporation
 *
 *****************************************************************************/
/*
 * Copyright(C) 2017 Renesas Electronics Corporation. All Rights Reserved.
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation.
 * No part of this program may be reproduced or disclosed to
 * others, in any form, without the prior written permission
 * of Renesas Electronics Corporation.
 *
 *****************************************************************************/
#ifndef RIVP_APP_VIN_DISP_H
#define RIVP_APP_VIN_DISP_H

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************/
/*                    INCLUDE FILES                                          */
/*****************************************************************************/
#include "rivp_types.h"
#include "rivp_vin_api.h"

/******************************************************************************/
/*                    MACROS/DEFINES                                          */
/******************************************************************************/
/* output unit */
#define RIVP_APP_VIN_DISP_UNIT_1		(1u)		/*!< unit #1 : HDMI0          */
#define RIVP_APP_VIN_DISP_UNIT_2		(2u)		/*!< unit #2 : HDMI1          */
#define RIVP_APP_VIN_DISP_UNIT_3		(3u)		/*!< unit #3 : Analog RGB     */

#define RIVP_APP_VIN_DISP_UNIT_HDMI0	RIVP_APP_VIN_DISP_UNIT_1	/*!< HDMI0        */
#define RIVP_APP_VIN_DISP_UNIT_HDMI1	RIVP_APP_VIN_DISP_UNIT_2	/*!< HDMI1        */
#define RIVP_APP_VIN_DISP_UNIT_RGB		RIVP_APP_VIN_DISP_UNIT_3	/*!< Analog RGB   */

#define RIVP_APP_VIN_DOC_RAM_ADDR			(0x00000000u)
#define RIVP_APP_VIN_DOC_THRESHOLD			(0x00000001u)

#define RIVP_APP_VIN_DOC_R_UP_LIMIT			(0x8u)  /// 888 : EE (238) 
#define RIVP_APP_VIN_DOC_G_UP_LIMIT			(0x8u)	/// 888 : EE (238) 
#define RIVP_APP_VIN_DOC_B_UP_LIMIT			(0x8u)	/// 888 : EE (238) 

#define RIVP_APP_VIN_DOC_R_LO_LIMIT			(0x0u)  /// 888 : 11 (17) 
#define RIVP_APP_VIN_DOC_G_LO_LIMIT			(0x0u)  /// 888 : 11 (17)
#define RIVP_APP_VIN_DOC_B_LO_LIMIT			(0x0u)	/// 888 : 11 (17)
#define RIVP_APP_VIN_DOC_MON_AREA_BIT		(0x00000001u) //enable monitor area 

/******************************************************************************/
/*                    TYPE DEFINITION                                         */
/******************************************************************************/
typedef struct {
	RIVP_U32				 unit;		/*!< 1:HDMI0, 2:HDMI1, 3:Analog RGB.  */
	RIVP_U32				 ch;		/*!< 0-3: output channel.             */
	RIVP_U32				 width;		/*!< window width                     */
	RIVP_U32				 height;	/*!< window height                    */
	RIVP_VIN_OUTPUT_FORMAT	 format;	/*!< output color format              */
	RIVP_U32				 bufferAddr;	/*!< output buffer Address        */
} RIVP_APP_VIN_DISP_PARAM_T;

/******************************************************************************/
/*                    FUNCTIONS                                               */
/******************************************************************************/
extern RIVP_BOOL RIVP_AppVinDocInit(const RIVP_APP_VIN_DISP_PARAM_T *prm);
extern RIVP_BOOL RIVP_AppVinDocDeinit(void);

extern RIVP_BOOL RIVP_AppVinDiscomInit(const RIVP_APP_VIN_DISP_PARAM_T *prm);
extern RIVP_BOOL RIVP_AppVinDiscomDeinit(void);

extern RIVP_BOOL RIVP_AppVinDispInit(const RIVP_APP_VIN_DISP_PARAM_T *prm);
extern RIVP_BOOL RIVP_AppVinDispDeinit(void);
extern RIVP_BOOL RIVP_AppVinDispUpdate(RIVP_U32 ch, const RIVP_VIN_OUTPUT_BUFF_T *buff);
extern RIVP_BOOL RIVP_AppVinDispWaitOutput(void);

// SM DISCOM function
extern RIVP_BOOL RIVP_AppVinDiscomInit(const RIVP_APP_VIN_DISP_PARAM_T *prm);
extern RIVP_BOOL RIVP_AppVinDiscomDeinit(void);

//display picture
extern void RIVP_AppVinPicDisplayTask (RIVP_PTR arg);
extern void RIVP_AppVinPicDisplayTerminateTask(void);

#ifdef __cplusplus
}
#endif

#endif /* RIVP_APP_VIN_DISP_H */
