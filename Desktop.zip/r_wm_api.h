/*
****************************************************************************
PROJECT : WM driver
FILE    : $Id: r_wm_api.h 10755 2016-10-27 15:29:40Z michael.golczewski $
============================================================================ 
DESCRIPTION
Driver for the Window Manager
============================================================================
                            C O P Y R I G H T
============================================================================
                       Copyright (c) 2015 - 2016
                                  by 
                       Renesas Electronics (Europe) GmbH. 
                           Arcadiastrasse 10
                          D-40472 Duesseldorf
                               Germany
                          All rights reserved.
============================================================================

DISCLAIMER

LICENSEE has read, understood and accepted the terms and conditions defined in
the license agreement, especially the usage rights. In any case, it is
LICENSEE's responsibility to make sure that any user of the software complies
with the terms and conditions of the signed license agreement.

***************************************************************************
*/


#ifndef WM_API_H
#define WM_API_H

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
  Title: RCAR Gen3 Window Manager API
  
  Window Manager API

*/

#ifdef R_WM_DEBUG
#include "r_bsp_common.h"
#define R_WM_Log(...) ((void)BSP_COMMON_USER_LOG_ERROR(__VA_ARGS__))
#else
#define R_WM_Log(...)
#endif

/***********************************************************/
/**
  @defgroup Version WM API Version
  @{
*/
/** @brief High number of the API version
*/
#define R_WM_VERSION_HI  (2U)
/** @brief Low number of the API version
*/
#define R_WM_VERSION_LO  (1U)

/** @} */

/***********************************************************
  Section: Global Types
*/

    
/***********************************************************/
/**
  @enum r_wm_Error_t

  @brief  WM driver error code.
  
  If an error occurs these enumerations give information about the
  reason.
*/
typedef enum
{
    /** General Errors */
    R_WM_ERR_OK                                 = 0, /**< Success                         */
    R_WM_ERR_NG                                 , /**< Failed. Error unknown           */
    R_WM_ERR_RANGE_WM                           , /**< Range Failed                    */
    R_WM_ERR_PARAM_INCORRECT                    , /**< Incorrect input parameters      */
    R_WM_ERR_NULL_PTR_ARGUMENT                  , /**< Input parameter pointer is NULL */
    R_WM_ERR_INVALID_WM_UNIT                    , /**< the given WM Unit is not valid  */
    R_WM_ERR_NOT_INITIALIZED                    , /**< WM is not initialised           */

    /* WM Device Error */
    R_WM_ERR_DEV_DEINIT_FAILED                  , /**< Failed to de-init the device            */
    R_WM_ERR_DEV_INIT_FAILED                    , /**< Failed to initialise the WM device      */
    R_WM_ERR_DEV_CALLBACK_SET_FAILED            , /**< Failed to set callback for the WM Device*/
    R_WM_ERR_DEV_EVENT_SET_FAILED               , /**< Failed to set Event for the device      */
    R_WM_ERR_DEV_WAITFOR_EVENT_FAILED           , /**< Error while waiting for event           */
    
    /* Screen setting errors */
    R_WM_ERR_SCREEN_ENABLE_FAILED               , /**< Failed to enbaled the display      */
    R_WM_ERR_SCREEN_DISABLE_FAILED              , /**< Failed to disable the display      */
    R_WM_ERR_SCREEN_BG_COLOR_FAILED             , /**< Failed to set the Background colour*/
    R_WM_ERR_SCREEN_TIMING_FAILED               , /**< Faiked to set the screen timing    */
    R_WM_ERR_SCREEN_NOT_DISABLED                , /**< The Screen is still enabled        */
    R_WM_ERR_SCREEN_COLOR_FORMAT_FAILED         , /**< Failed to set Colour format        */
    R_WM_ERR_SCREEN_TIMING_NOT_SET              , /**< Timing is not set                  */

    /* Du DOC Error */
    R_WM_ERR_DOC_PARAM_SET_FAILED               , /**< Failed to DU DOC set Parameter     */
    R_WM_ERR_DOC_DEINIT_FAILED                  , /**< Failed to de-initialize the DU DOC */
    R_WM_ERR_DOC_INIT_FAILED                    , /**< Failed to initialize the DU DOC    */
    R_WM_ERR_DOC_COLOR_SET_FAILED               , /**< Failed to set the color RAM table  */
    R_WM_ERR_DOC_AREA_SET_FAILED                , /**< Failed to set moitor area          */
    R_WM_ERR_DOC_CHK_ENABLE_FAILED              , /**< Failed to enable VOCA              */
    R_WM_ERR_DOC_CHK_DISABLE_FAILED             , /**< Failed to disable VOCA             */
    R_WM_ERR_DOC_STATUS_CLEAR_FAILED            , /**< Failed to clear the DOC status     */
    R_WM_ERR_DOC_STATUS_GET_FAILED              , /**< Failed to get the DOC status       */
    R_WM_ERR_DOC_MON_ENABLE_FAILED              , /**< Failed to enable activity monitor  */
    R_WM_ERR_DOC_MON_DISABLE_FAILED             , /**< Failed to disable activity monitor */
    R_WM_ERR_DOC_INTC_ENABLE_FAILED             , /**< Failed to enable the DOC interrupts*/
    R_WM_ERR_DOC_WAIT_FAILED                    , /**< No semaphore registerd for event   */
    
    /* VSP Error */
    R_WM_ERR_VSP_INIT_FAILED                    , /**< VSP unit initialisation failed   */
    R_WM_ERR_VSP_DEINIT_FAILED                  , /**< VSP unit de-initialisation failed*/
    R_WM_ERR_VSP_ENABLE_FAILED                  , /**< Failed to enable VSP unit        */
    R_WM_ERR_VSP_DISABLE_FAILED                 , /**< Failed to disable VSP unit       */
    R_WM_ERR_INVALID_VSP_UNIT                   , /**< VSP unit is invalid              */
    R_WM_ERR_INVALID_LAYER_NUMBER               , /**< Wrong layer member               */

    /* Memory Error */
    R_WM_ERR_MALLOC_FAILED                      , /**< Failed to alloc memory*/
    R_WM_ERR_FREE_FAILED                        , /**< Failed to free memory */
    R_WM_ERR_UNMAP_FAILED                       , /**< Failed to Map memory  */

    /* Window Surface Error */
    R_WM_ERR_WIN_CREATE_FAILED                  , /**< Failed to create window surface       */
    R_WM_ERR_WIN_DELETE_FAILED                  , /**< Failed to delete window surface       */
    R_WM_ERR_WIN_ENABLE_FAILED                  , /**< Failed to enable window               */
    R_WM_ERR_WIN_DISABLE_FAILED                 , /**< Failed to disable window              */
    R_WM_ERR_WIN_INFO_GET_FAILED                , /**< Failed to get the window information  */
    R_WM_ERR_WIN_EXTERNAL_BUF_SET_FAILED        , /**< Setting of the external buffer failed */
    R_WM_ERR_WIN_MOVE_FAILED                    , /**< Window move failed                    */
    R_WM_ERR_WIN_RESIZE_FAILED                  , /**< REsizing the window failed            */
    R_WM_ERR_WIN_GEOMETRY_SET_FAILED            , /**< Failed to re-set the Layer geometry   */
    R_WM_ERR_WIN_COLORFMT_FAILED                , /**< Setting the colour format failed      */
    R_WM_ERR_WIN_CLUT_FAILED                    , /**< Failed to set the CLUT                */
    R_WM_ERR_WIN_NOT_CLUT_FMT                   , /**< Window format is not CLUT             */
    R_WM_ERR_WIN_ALPHA_FAILED                   , /**< Failed to set the ALPHA value         */
    R_WM_ERR_WIN_PREMULT_ALPHA_ENABLE_FAILED    , /**< Failed to enable pre-multiplied alpha */
    R_WM_ERR_WIN_PREMULT_ALPHA_DISABLE_FAILED   , /**< Failed to disable pre-multiplied alpha*/
    R_WM_ERR_WIN_SWAP_FAILED                    , /**< Buffer swap failed                    */
    R_WM_ERR_WIN_INCORRECT_SURFACE_TYPE         , /**< Incorrect surface type was given      */
    
    /* Texture Sync mechanism Error */
    R_WM_ERR_TEXTURE_LOCK_FAILED                , /**< Texture lock failed  */
    R_WM_ERR_TEXTURE_UNLOCK_FAILED              , /**< Texture unlock failed*/
    
    /* Capture Error */
    R_WM_ERR_CAPTURE_CREATE_FAILED              , /**< Failed to create capture surface                   */
    R_WM_ERR_CAPTURE_DELETE_FAILED              , /**< Failed to delete capture surface                   */
    R_WM_ERR_CAPTURE_ENABLE_FAILED              , /**< Failed to enable the capture surface               */
    R_WM_ERR_CAPTURE_DISABLE_FAILED             , /**< Failed to disable the capture surface              */
    R_WM_ERR_CAPTURE_WINDOW_NOT_SUITABLE        , /**< The capture window does not match the configuration*/
    
    /* Connection error */
    R_WM_ERR_UB_CREATE_ACTIVITY_FAILED          , /**< Failed to create activity      */
    R_WM_ERR_UB_SENDBUF_FAILED                  , /**< Failed to send buffer          */
    R_WM_ERR_UB_RECEIVEBUF_FAILED               , /**< Failed to receive buffer       */
    R_WM_ERR_UB_CONNECT_FAILED                  , /**< Connection failed              */
    R_WM_ERR_UB_DISCONNECT_FAILED               , /**< Disconnection failed           */
    R_WM_ERR_UB_CREATE_SEMAPHORE_FAILED         , /**< Failed to create semaphore     */
                                                       
    /* Properties errors */                            
    R_WM_ERR_UNKNOWN_PROPERTY                   , /**< This property is not defined   */
    R_WM_ERR_DEV_PROP_SET_FAILED                , /**< Failed to set the property data*/
    R_WM_ERR_DEV_PROP_GET_FAILED                , /**< Failed to get the property data*/
 
    /* DISCOM errors */   
    R_WM_ERR_DISCOM_INIT_FAILED                 , /**< Init failed                     */
    R_WM_ERR_DISCOM_DEINIT_FAILED               , /**< De-Init failed                  */
    R_WM_ERR_DISCOM_SET_FAILED                  , /**< Could not set Data              */
    R_WM_ERR_DISCOM_GET_FAILED                  , /**< Could not get CRC or Status     */
    R_WM_ERR_DISCOM_WAIT_FAILED                 , /**< Wait for interrupt failed       */
    R_WM_ERR_LAST                                 /**< Last error enum. Use for boundary check*/
} r_wm_Error_t;

/***********************************************************/
/**
  @enum r_wm_WinStatus_t

  @brief  List of the possible status of a window
*/
typedef enum
{
    R_WM_WINSTATUS_NOT_INITIALIZED = 0, /**< The window has not been created.      */
    R_WM_WINSTATUS_INITIALIZED     = 1, /**< Window has been initialised.          */
    R_WM_WINSTATUS_DISABLED        = 2, /**< The window is invisible on the screen.*/
    R_WM_WINSTATUS_ENABLED         = 3  /**< The window is visible on the screen.  */
} r_wm_WinStatus_t;

/***********************************************************/
/**
  @enum r_wm_WinBufAllocMode_t

  @brief  Flag specifying how the buffers of a given surface are allocated
          They can be allocated internally by the WM or externally by the application.
*/
typedef enum
{
    R_WM_WINBUF_ALLOC_EXTERNAL, /**< The Buffers of the window surface are not allocated by the WM when calling <R_WM_WindowCreate>. The application
                                     has to do it and then pass the buffer's address to the WM using the function <r_wm_WindowExternalBufSet>*/
    R_WM_WINBUF_ALLOC_INTERNAL  /**< The buffers are allocated by WM when the function <R_WM_WindowCreate> is called*/
} r_wm_WinBufAllocMode_t;

/***********************************************************/
/**
  @enum r_wm_WinColorFmt_t

  @brief  A parameter of this type specifies the colour mode of a window. 
          (A)RGB(w)xyz - The value specifies the number of bits for each colour and the alpha channel.
          Note:  Not all displays support all formats.
*/
typedef enum
{
    R_WM_COLORFMT_RGB565,   /**< 16bit                   rrrrrggggggbbbbb*/
    R_WM_COLORFMT_ARGB1555, /**< 16bit                   arrrrrgggggbbbbb*/
    R_WM_COLORFMT_ARGB4444, /**< 16bit                   aaaarrrrggggbbbb*/
    R_WM_COLORFMT_RGB0888,  /**< 32bit   --------rrrrrrrrggggggggbbbbbbbb*/
    R_WM_COLORFMT_ARGB8888, /**< 32bit   aaaaaaaarrrrrrrrggggggggbbbbbbbb*/
    R_WM_COLORFMT_RGBA5551, /**< 16bit                   rrrrrgggggbbbbba*/
    R_WM_COLORFMT_RGBA4444, /**< 16bit                   rrrrggggbbbbaaaa*/
    R_WM_COLORFMT_RGBA8888, /**< 32bit   rrrrrrrrggggggggbbbbbbbbaaaaaaaa*/
    R_WM_COLORFMT_ALPHA8,   /**<  8 bit   8-bit alpha value              */
    
    R_WM_COLORFMT_CLUT8,    /**<  8 bit   8-bit (256 colors) color-lookup index*/
    /* RLE supported format*/
    R_WM_COLORFMT_RLE24ARGB8888,/**< 24bit RLE compressed*/
    R_WM_COLORFMT_RLE24RGB0888, /**< 24bit RLE compressed*/
    R_WM_COLORFMT_RLE18ARGB8888,/**< 18bit RLE compressed*/
    R_WM_COLORFMT_RLE18RGB0888, /**< 18bit RLE compressed*/
    R_WM_COLORFMT_RLE8CLUT8,    /**<  8bit RLE compressed*/
    R_WM_COLORFMT_RLE8CLUT4,    /**<  8bit RLE compressed*/
    R_WM_COLORFMT_RLE8CLUT1,    /**<  8bit RLE compressed*/

    /* In digial domain, YUV is named YCbCr */
    R_WM_COLORFMT_YCBCR422_NV16_2PL, /* Semi planar*/
    R_WM_COLORFMT_YCBCR422_NV61_2PL, /* Semi planar*/
    R_WM_COLORFMT_YCBCR420_NV12_2PL, /* Semi planar*/
    R_WM_COLORFMT_YCBCR420_NV21_2PL, /* Semi planar*/
    R_WM_COLORFMT_YCBCR422_UYVY,
    R_WM_COLORFMT_YCBCR422_YUY2,
    R_WM_COLORFMT_YCBCR422_YVYU,
    R_WM_COLORFMT_YCBCR420,
    R_WM_COLORFMT_YCBCR422,

    R_WM_COLORFMT_YCBCR_CLUT,

    R_WM_COLORFMT_LAST          /**< Last enum. Use for boundary check*/
} r_wm_WinColorFmt_t;

/***********************************************************/
/**
  @enum r_wm_OutColorFmt_t

  @brief A parameter of this type specifies the colour mode of the video output. 
        (A)RGB(w)xyz - The value specifies the number of bits for each colour.

  Note:
  Not all displays support all formats.
*/
typedef enum
{
    R_WM_OUTCOLORFMT_RGB888 = 0u, /**< 24bit           rrrrrrrrggggggggbbbbbbbb*/
    R_WM_OUTCOLORFMT_RGB666 = 1u, /**< 18bit           ------rrrrrrggggggbbbbbb*/
    R_WM_OUTCOLORFMT_RGB565 = 2u, /**< 16bit           --------rrrrrggggggbbbbb*/
    R_WM_OUTCOLORFMT_LAST   = 3u  /**< Last enum. Use for boundary check*/
} r_wm_OutColorFmt_t;

/***********************************************************/
/**
  @enum r_wm_EventId_t
  @brief External event id. 
  
  An event can be registered by an application.
  In that case the Event gets its own counting semaphore which will be triggered
  by the WM Server when the event occurred
*/

typedef enum
{
    R_WM_EVENT_VBLANK      = 0x0, /**< Vertical blank interrupt notification  */
    R_WM_EVENT_HBLANK      = 0x1, /**< Horizontal blank interrupt notification*/
    R_WM_EVENT_RASTER      = 0x2, /**< Raster Interrupt notification          */
    R_WM_EVENT_UNDERRUN    = 0x3, /**< Underrun Interrupt notification        */
    R_WM_EVENT_TEXTURESWAP = 0x4, /**< Texture swap occurred.                 */
    R_WM_EVENT_LAST               /**< Last enum. Use for boundary check*/
} r_wm_EventId_t;

/***********************************************************/
/**
  @enum r_wm_Memory_t

  @brief List of Memory type.
*/
typedef enum
{
    R_WM_MEM_HOST  = 0,/**< OS allocates memory from the application heap      */
    R_WM_MEM_VIDEO = 1 /**< the memory is allocated in the Video memory region.*/
} r_wm_Memory_t;

/***********************************************************/
/**
  @enum r_wm_SurfaceType_t

  @brief List of surface types.

*/
typedef enum
{
    R_WM_SURFACE_FB       = 0, /**< Surface is a Vout Layer   */
    R_WM_SURFACE_TEXTURE  = 1, /**< Surface is a texture.     */
    R_WM_SURFACE_TYPE_NUM = 2  /**< Number of supported types */
} r_wm_SurfaceType_t;


/*******************************************************************************/
/** 
    @struct r_wm_VspdInfo_t 
    @brief  VSPD Information  
*/
typedef struct
{
    int32_t             BlendUnit; /**< Blend Unit supported by a VSPD unit */
} r_wm_VspdInfo_t;

/*******************************************************************************/
/**
  @struct r_wm_DocParam_t
  @brief DOC parameter.
*/
typedef struct
{
    uint16_t h_offset; /**< Horizontal back porch offset in pixels. */
    uint16_t v_offset; /**< Vertical back porch offset in lines. */
    uint16_t h_size;   /**< Horizontal size image in pixels. */
    uint16_t v_size;   /**< Vertical size image in pixels. */
} r_wm_DocParam_t;

/*******************************************************************************/
/**
  @struct r_wm_DocMonRefColor_t 
  @brief  Video Output Monitor reference color.
*/  
typedef struct
{
    uint8_t r_upper; /**< Red upper limit.  */
    uint8_t g_upper; /**< Green upper limit.  */
    uint8_t b_upper; /**< Blue upper limit.  */
    uint8_t r_lower; /**< Red lower limit.  */
    uint8_t g_lower; /**< Green lower limit.  */
    uint8_t b_lower; /**< Blue lower limit.  */
} r_wm_DocMonRefColor_t;

/*******************************************************************************/
/** 
    @struct r_wm_DocMonArea_t 
    @brief  Video Output Monitor area information.
*/    
typedef struct
{
    uint16_t monarea_num; /**< Video Output Monitor area number(0-15). */
    uint16_t h_start;     /**< Video Output Monitor area horizontal start point in pixels. */
    uint16_t v_start;     /**< Video Output Monitor area vertical start point in pixels. */
    uint16_t h_size;      /**< Video Output Monitor area horizontal size in pixels. */
    uint16_t v_size;      /**< Video Output Monitor area vertical size in pixels. */
    uint16_t ram_addr;    /**< Video Output Monitor reference RAM start address. */
    uint32_t threshold;   /**< Video Output Monitor acceptance threshold. */
    r_wm_DocMonRefColor_t ref_col[4]; /**< @see r_wm_DocMonRefColor_t. */
} r_wm_DocMonArea_t;

/*******************************************************************************/
/** 
    @enum   r_wm_DocIntType_t 
    @brief  List of the supported DOC interrupts. 
*/
typedef enum
{
    R_WM_DOC_INTC_DISABLE = 0,          /**< Disable interrupts. */
    R_WM_DOC_INTC_VOC     = (1ul << 0), /**< Video Output Monitor error interrupt. */
    R_WM_DOC_INTC_ACTMON  = (1ul << 1)  /**< Activity Monitor error interrupt. */
} r_wm_DocIntType_t;

/***********************************************************/
/**
   @enum  r_wm_ScreenProperty_t
   @brief  List of  Display Output properties supported by the Window Manager.
   
   It includes the display output Colour Management (CMM), the display output checker
   (DOC) and the Display Output Compare (DISCOM)
*/
typedef enum
{
    R_WM_DISCOM,                /**< DIsplay Ouput Compare */
    R_WM_DOC,                   /**< Display Output Checker */
    R_WM_CMM_MODE,              /**< Display CMM function Mode */
    R_WM_CMM_BRIGHTNESS,        /**< Display CMM LUT (background) brightness */
    R_WM_CMM_GAMMA,             /**< Display CMM LUT gamma */
    R_WM_CMM_CONTRAST,          /**< Display CMM LUT contrast  */
    R_WM_CMM_LUT,               /**< Display CMM LUT configuration  */ 
    R_WM_CMM_CLU,               /**< Display CMM CLU configuration */
    R_WM_CMM_HGO,               /**< Display CMM HGO configuration */  
    R_WM_CMM_LAST               /**< WM property delimiter   */
}r_wm_ScreenProperty_t;

/***********************************************************/
/** 
   @enum  r_wm_ScreenPropertyMode_t
   @brief  List of modes that can be applied to a given display output property using the function
           R_WM_ScreenXXXSetProperty where XXX correspond to CMM
*/
typedef enum
{
    R_WM_SCREEN_PROPERTY_DISABLE,     /**< The selected property/function will be disabled   */
    R_WM_SCREEN_PROPERTY_ENABLE,      /**< The selected property/function will be enabled    */
    R_WM_SCREEN_PROPERTY_RESET        /**< The selected property/function will be reset      */
}r_wm_ScreenPropertyMode_t;


/*******************************************************************************/
/** 
   @enum   r_wm_CmmFunc_t
   @brief  List of the supported CMM functions.
*/
typedef enum
{
    R_WM_CMM_FUNC_NONE,     /**< No function. */
    R_WM_CMM_FUNC_LUT,      /**< Look Up Table (LUT). */
    R_WM_CMM_FUNC_CLU,      /**< Cubic Look up Table (CLU). */
    R_WM_CMM_FUNC_HGO       /**< Histogram Function  */
} r_wm_CmmFunc_t;


/*******************************************************************************/
/** 
   @enum   r_wm_CmmBufferSide_t
   @brief  List of the supported CMM buffer side.
*/
typedef enum
{
    R_WM_CMM_BUFFER_SIDE_A,     /**< Buffer side A. */
    R_WM_CMM_BUFFER_SIDE_B,     /**< Buffer side B. */
} r_wm_CmmBufferSide_t;


/*******************************************************************************/
/** 
   @enum   r_wm_CmmBufferMode_t
   @brief  List of the supported CMM buffer mode.
*/
typedef enum
{
    R_WM_CMM_BUFFER_MODE_SINGLE,     /**< Single Buffer Mode. */
    R_WM_CMM_BUFFER_MODE_DOUBLE,     /**< Double Buffer Mode. */
} r_wm_CmmBufferMode_t;


/*******************************************************************************/
/** 
    @struct r_wm_CmmCfg_t 
    @brief  Window Manager CMM configuration setting 
*/
typedef struct 
{
    r_wm_ScreenPropertyMode_t Mode;     /**< Mode for the selected property (@ref r_wm_ScreenPropertyMode_t) */
    r_wm_CmmFunc_t            CmmFunc;  /**< CMM Function selection (@ref r_wm_CmmFunc_t). */
    r_wm_CmmBufferSide_t      BuffSide;    /**< CMM buffer side */
    r_wm_CmmBufferMode_t      CluBuffMode; /**< CMM CLU buffer mode (@ref r_wm_CmmBufferMode_t). */
    r_wm_CmmBufferMode_t      LutBuffMode; /**< CMM LUT buffer mode (@ref r_wm_CmmBufferMode_t). */
} r_wm_CmmCfg_t; 

/*******************************************************************************/
/** 
    @struct r_wm_CmmCluCfg_t
    @brief  WindowManager CMM CLU configuration structure.
*/
typedef struct 
{
    uint32_t            Offset;    /**< Index of the first updated color for CLU of CMM. */
    uint32_t            Size;      /**< Number of table entries for CLU of CMM */
    const uint32_t    * CluTable;  /**< Color look-up table of CMM */
    r_wm_CmmBufferSide_t      BuffSide;    /**< CMM buffer side */
} r_wm_CmmCluCfg_t; 

/*******************************************************************************/
/** 
    @struct r_wm_LutCfg_t
    @brief  WindowManager CMM LUT configuration structure.
*/
//typedef uint32_t * r_wm_LutCfg_t;          /**< Pointer to the Look-up table of CMM. */
typedef struct 
{
    const uint32_t    * LutTable;          /**< Pointer to the Look-up table of CMM. */
    r_wm_CmmBufferSide_t      BuffSide;    /**< CMM buffer side */
} r_wm_LutCfg_t; 

/*******************************************************************************/
/** 
    @struct r_wm_LutSet_t
    @brief  WindowManager CMM LUT setting structure.
*/
typedef struct 
{
    uint32_t                  Value;       /**< Setting value. */
    r_wm_CmmBufferSide_t      BuffSide;    /**< CMM buffer side */
} r_wm_LutSet_t; 

/***************************************************************************/
/** 
    @struct   r_du_CmmLBDZoneInfo_t 
    @brief    Letter Box Detection Zone Information for the CMM HGO 
*/
typedef struct
{
    uint16_t h_start_pos; /**< Horizontal Start Position for Letter Box Detection Zone. */
    uint16_t h_end_pos;   /**< Horizontal Start Position for Letter Box Detection Zone. */
    uint16_t v_start_pos; /**< Vertical Start Position for Letter Box Detection Zone. */
    uint16_t v_end_pos;   /**< Vertical End Position for Letter Box Detection Zone. */
} r_wm_CmmHgoLBDZoneInfo_t;

/*******************************************************************************/
/** 
    @struct   r_du_CmmHgoSelector_t
    @brief    Histogram selector. 
*/
typedef enum
{
    R_WM_CMM_HGO_SELECT_BEFORE_CLU, /**< Histogram data is measured before CLU processing. */
    R_WM_CMM_HGO_SELECT_BEFORE_LUT  /**< Histogram data is measured before LUT processing. */
} r_wm_CmmHgoSelector_t;

/***************************************************************************/
/** 
    @struct r_wm_HgoCfg_t
    @brief  HGO parameter. 
*/
typedef struct
{
    uint16_t h_offset;                  /**< Horizontal Offset of Histogram Detection Window. */
    uint16_t v_offset;                  /**< Vertical Offset of Histogram Detection Window. */
    uint16_t h_size;                    /**< Horizontal Size of Histogram Detection Window. */
    uint16_t v_size;                    /**< Vertical Size of Histogram Detection Window. */
    uint16_t mode;                      /**< HGO mode. */
    uint8_t  threshold;                 /**< Threshold for Black Level Determination in Letter Box Detection. */
    r_wm_CmmHgoLBDZoneInfo_t lbd_zone[4];  /**< Letter Box Detection Zone Information ( See @ref r_wm_CmmLBDZoneInfo_t). */
    r_wm_CmmHgoSelector_t    selector;       /**< Histogram selector (See @ref r_wm_CmmHgoSelector_t). */
} r_wm_CmmHgoCfg_t;

/***************************************************************************/
/** 
    @struct   r_wm_HgoInfo_t
    @brief    Histogram information. 
*/
typedef struct
{
    uint32_t r_histogram[64]; /**< Frequency of Component-R in the value range. */
    uint16_t r_maxval;        /**< Maximum Value of Component-R. */
    uint16_t r_minval;        /**< Minimum Value of Component-R. */
    uint32_t r_sumval;        /**< Sum of Component-R. */
    uint32_t r_result;        /**< Component-R LB Detection Result. */
    uint32_t g_histogram[64]; /**< Frequency of Component-G in the value range. */
    uint16_t g_maxval;        /**< Maximum Value of Component-G. */
    uint16_t g_minval;        /**< Minimum Value of Component-G. */
    uint32_t g_sumval;        /**< Sum of Component-G. */
    uint32_t g_result;        /**< Component-G LB Detection Result. */
    uint32_t b_histogram[64]; /**< Frequency of Component-B in the value range. */
    uint16_t b_maxval;        /**< Maximum Value of Component-B. */
    uint16_t b_minval;        /**< Minimum Value of Component-B. */
    uint32_t b_sumval;        /**< Sum of Component-B. */
    uint32_t b_result;        /**< Component-B LB Detection Result. */
} r_wm_CmmHgoInfo_t;

/***************************************************************************/
/** 
    @enum   r_wm_DiscomTarget_t 
    @brief  The Image that DISCOM calculates the CRC.
*/
typedef enum
{
    R_WM_DISCOM_TGT_IN0      = 0,    /**< Input image 0. */
    R_WM_DISCOM_TGT_IN1      = 1,    /**< Input image 1. */
    R_WM_DISCOM_TGT_IN2      = 2,    /**< Input image 2. */
    R_WM_DISCOM_TGT_IN3      = 3,    /**< Input image 3. */
    R_WM_DISCOM_TGT_IN4      = 4,    /**< Input image 4. */
    R_WM_DISCOM_TGT_BLEND    = 5,    /**< Blending image.(BRU) */
    R_WM_DISCOM_TGT_BLENDSUB = 6     /**< Blending image.(BRS) */
} r_wm_DiscomTarget_t;

/***************************************************************************/
/** 
    @enum   r_wm_DiscomAlpha_t
    @brief  The alpha value which is used for CRC calculation.
*/
typedef enum
{
    R_WM_DISCOM_ALPHA_PIXEL   = 0, /**< Use alpha value with pixel value. */
    R_WM_DISCOM_ALPHA_DEFAULT = 1  /**< Use default alpha value. */
} r_wm_DiscomAlpha_t;

/***************************************************************************/
/** 
    @struct   r_wm_DiscomParam_t
    @brief    DISCOM parameter
*/
typedef struct
{
    uint16_t            h_offset;    /**< horizontal offset of the CRC calculation area. */
    uint16_t            v_offset;    /**< vertical offset of the CRC calculation area. */
    uint16_t            h_size;      /**< horizontal size of the CRC calculation area. */
    uint16_t            v_size;      /**< vertical size of the CRC calculation area. */
    r_wm_DiscomAlpha_t  alpha_mode;  /**< alpha mode to use (see r_wm_DiscomAlpha_t). */
    uint8_t             alpha;       /**< default alpha value. */
    uint8_t             threshold;   /**< threshold value for an interruption. */
} r_wm_DiscomParam_t;

/***************************************************************************/
/** 
    @enum   r_wm_DiscomUif_t
    @brief  DISCOM UIF selector. 
*/
typedef enum
{
    R_WM_DISCOM_SELECT_UIF4 = 0, /**< UIF4 */
    R_WM_DISCOM_SELECT_UIF5 = 1  /**< UIF5(VSPDL only) */
} r_wm_DiscomUif_t;

/***************************************************************************/
/** 
    @struct r_wm_DiscomCfg_t 
    @brief  DISCOM configuration. 
*/
typedef struct
{
    r_wm_DiscomParam_t   Param;     /**< Struture contaiing the DISCOM parameters. @ref r_wm_DiscomParam_t*/
    r_wm_DiscomUif_t     UifSelect; /**< The UIF selected. @ref r_wm_DiscomUif_t*/
    r_wm_DiscomTarget_t  Target;    /**< Image that the DISCOM will use to calculate CRC. @ref r_wm_DiscomTarget_t*/
} r_wm_DiscomCfg_t;

/***********************************************************/
/**
    @struct r_wm_ClutEntry_t
    @brief  Defines an entry of the colour lookup table.
*/
typedef struct
{
    uint8_t B; /**< blue component */
    uint8_t G; /**< green component*/
    uint8_t R; /**< red component  */
    uint8_t A; /**< alpha component*/
} r_wm_ClutEntry_t;

/*******************************************************************************/
/** 
    @struct r_wm_WinSrvHandle_t
    @brief  WM Server Surface handle. 
*/
typedef void r_wm_WinSrvHandle_t;

/*******************************************************************************/
/** 
    @struct r_wm_MemSrvHandle_t
    @brief  WM Server memory Object handle. 
*/
typedef void r_wm_MemSrvHandle_t;

/*******************************************************************************/
/** 
    @struct r_wm_Window_t
    @brief  forward declaration for r_wm_Window_s
*/
typedef struct r_wm_Window_s r_wm_Window_t; /* need forward declaration here */

/*******************************************************************************/
/** 
    @struct r_wm_Window_s
    @brief  Each window has a data structure of this type. 
            All windows are linked in a chain by the window manager.

    Initialization instructions:
    It is required to clear the memory of r_wm_Window_t to zero.
  
    The following variables need to be initialised to any valid value (including zero) 
    before calling <R_WM_WindowCreate>. This is already covered by clearing everything to zero.
        PosX
        PosY
        PosZ
        UsePremultipliedAlpha
        ClutNumEntries
  
    The following variables need use-case specific setup before calling R_WM_WindowCreate
        Mode
        ColorFmt
        Pitch
        Width
        Height
        Surface.Type
        Surface.BufNum
        Surface.BufMode
        Surface.Buffer
        Alpha
        ClutNumEntries        (if ColorFmt is a CLUT format)
        Clut                  (if ColorFmt is a CLUT format)
  
    The following variables are set by R_WM_WindowCreate, so initialization value is not important
        Status
        SurfHandle - Reference to the Window manager server surface.
*/
struct r_wm_Window_s
{
    r_wm_WinStatus_t    Status;     /**< The element keeps the status of the window; see r_wm_WinStatus_t.                 */
    r_wm_WinColorFmt_t  ColorFmt;   /**< The member specifies the color mode of the window; see r_wm_WinColorFmt_t.        */
    uint32_t            Unit;       /**< reference to the WM Device, see r_wm_dev_num_t*/
    int32_t             PosX;       /**< X position of the window on the screen.*/
    int32_t             PosY;       /**< Y position of the window on the screen.                                      */
    uint32_t            PosZ;       /**< Z position of the window on the screen. Correspond the VSP layer number      */
    uint32_t            Pitch;      /**< This is the line pitch of a frame buffer. It must be greater or equal Width.                                            */
    uint32_t            Width;      /**< Width of the window*/
    uint32_t            Height;     /**< Hwigh of the window*/

/* [Golo] Disable MISRA checks here  */
/* Rule 5.3 is violated, because Integrity defines a Buffer type, 
  and we cannot change either GHS nor this code */
#if defined (__ghs__)
#pragma ghs startnomisra
#endif


    struct
    {
        r_wm_SurfaceType_t      Type;        /**< Type of Surface*/
        r_mmgr_MemBlock_t    ** Buffer;      /**< Pointer to the MMGR buffers, see r_mmgr_MemBlock_t*/
        uint8_t                 BufNum;      /**< Number of buffers for the given surface*/
        r_wm_WinBufAllocMode_t  BufMode;     /**< Buffer allocation mode, see r_wm_WinBufAllocMode_t*/
        r_wm_WinSrvHandle_t   * SurfHandle;  /**< pointer to the WMserver Window handle */
    } Surface; /**< Window surface framebuffer configuration*/

#if defined (__ghs__)
#pragma ghs endnomisra
#endif

    uint8_t                     Alpha;                  /**< Constant alpha of the window*/
    uint8_t                     UsePremultipliedAlpha;  /**< MultipliedAlpha configuration*/
    
    uint32_t                    ClutNumEntries; /**< Number of entries in the CLUT*/
    const r_wm_ClutEntry_t    * Clut;           /**< color for the color indexed color keying, see r_wm_ClutEntry_t*/
    
    struct r_wm_Window_s      * Next;    /**< internal. Points to the next window allocated in the current process*/
};

/*******************************************************************************/
/** 
    @enum   r_wm_CapMode_t
    @brief  There are different modes of video capturing, especially for interlaced videos. 
            This type is used to describe, which method is to be used for a capturing surface.

    Initialization instructions:
    One of these five flags must be selected or the function call will fail :

        R_WM_CAPMODE_YCBCR422_ITU656_8BIT     - Select YCbCr422 ITU656 mode
        R_WM_CAPMODE_YCBCR422_ITU656_10BIT    - Select YCbCr422 ITU656 mode 10 bit
        R_WM_CAPMODE_YCBCR422_ITU656_12BIT    - Select YCbCr422 ITU656 mode 12 bit
        R_WM_CAPMODE_RGB666_ITU601            - Select RGB 666 bit mode 
        R_WM_CAPMODE_RGB888_ITU601            - Select RGB 888 bit mode 

    The following flags are optional and can be omitted :

        Dithering can be used with framebuffer format R_VIN_FB_FORMAT_RGB565 and R_VIN_FB_FORMAT_ARGB1555. 
        Dithering is set to "dithering with cumulative addition" on default. To enable "ordered dithering",
        use the following flag:

            R_WM_CAPMODE_DITHER_ORDERED           - Select ordered dithering mode

        The interlace mode of the VIN can be selected using the following flags:

            R_WM_CAPMODE_INTERLACE_WEAVE          - Weaves both fields into one frame. 
            R_WM_CAPMODE_INTERLACE_ODD            - Only capture the odd field of the interlace video
            R_WM_CAPMODE_INTERLACE_EVEN           - Only capture the even field of the interlace video
  
        The device's single capture mode can be enabled by the following flag. Calling
        <R_VIN_Enable> will then lead to the capturing of a single frame.
  
            R_WM_CAPMODE_SINGLE                   - Select single frame capture mode.
*/
typedef enum
{
    R_WM_CAPMODE_NONE                   = 0, /**< No mode selected */
    R_WM_CAPMODE_YCBCR422_ITU656_8BIT   = (int32_t)(1uL<< 0), /**< Select YCbCr422 ITU656 mode */
    R_WM_CAPMODE_YCBCR422_ITU656_10BIT  = (int32_t)(1uL<< 1), /**< Select YCbCr422 ITU656 mode 10 bit*/
    R_WM_CAPMODE_YCBCR422_ITU656_12BIT  = (int32_t)(1uL<< 2), /**< Select YCbCr422 ITU656 mode 12 bit*/
    R_WM_CAPMODE_RGB666_ITU601          = (int32_t)(1uL<< 3), /**< Select RGB 666 bit mode*/
    R_WM_CAPMODE_RGB888_ITU601          = (int32_t)(1uL<< 4), /**< Select RGB 888 bit mode*/
    R_WM_CAPMODE_DITHER_ORDERED         = (int32_t)(1uL<< 5), /**< Select ordered dithering mode*/
    R_WM_CAPMODE_INTERLACE_WEAVE        = (int32_t)(1uL<< 6), /**< Weaves both fields into one frame.*/
    R_WM_CAPMODE_INTERLACE_ODD          = (int32_t)(1uL<< 7), /**< Only capture the odd field of the interlace video*/
    R_WM_CAPMODE_INTERLACE_EVEN         = (int32_t)(1uL<< 8), /**< Only capture the even field of the interlace video*/
    R_WM_CAPMODE_INTERLACE_ODD_EVEN     = (int32_t)(1uL<< 9), /**< Capture bothe odd and even field*/
    R_WM_CAPMODE_SINGLE                 = (int32_t)(1uL<< 10) /**< Select single frame capture mode*/
} r_wm_CapMode_t;


/*******************************************************************************/
/** 
    @enum   r_wm_CapSrc_t
    @brief  The VIN unit can take as input Data or the MIPI CSIx outputs.
            This types provides the list of available source.
*/
typedef enum
{
    R_WM_CAPTSRC_DATA       = 0, /**< Select Data as source. Note only valid with VIN4 and VIn5 */
    R_WM_CAPTSRC_MIPI       = 1, /**< MIPI as source */

    R_WM_CAPTSRC_LAST           /**< Last enum value. Used for boundary check */
} r_wm_CapSrc_t;

/*******************************************************************************/
/** 
    @enum   r_wm_CapVInConfig_t
    @brief  List of the possible mapping between Vin channel and MIPI-CSI2 output
*/
/**
    <table>
    <caption id="VinConfigH3"> VIn configuration R-Car H3</caption>
    <tr><th> Capture Mode <th>  VIN0  <th>  VIN1  <th>  VIN2  <th>  VIN3  <th>  VIN4 <th>   VIN5  <th>  VIN6  <th>  VIN7
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_0 
    <td>CSI40 <td>  CSI20 <td> CSI21 <td> CSI40 <td> CSI41 <td> CSI20 <td> CSI21 <td> CSI41
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_1
    <td>CSI20 <td>  CSI21 <td>  CSI40 <td>  CSI20 <td>  CSI20 <td>  CSI21 <td>  CSI41 <td>  CSI20
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_2
    <td>CSI21 <td>  CSI40 <td>  CSI20 <td>  CSI21 <td>  CSI21 <td>  CSI41 <td>  CSI20 <td>  CSI21
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_3
    <td>CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI41 <td>  CSI41 <td>  CSI41 <td>  CSI41
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_4
    <td>CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_5
    <td>CSI21 <td>  CSI21 <td>  CSI21 <td>  CSI21 <td>  CSI21 <td>  CSI21 <td>  CSI21 <td>  CSI21
    </table>
    
    <table>
    <caption id="VinConfigM3"> VIn configuration R-Car M3</caption>
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_0
    <td>CSI40 <td>  CSI20 <td>  N/A <td>    CSI40 <td>  CSI40 <td>  CSI20 <td>  N/A <td>    CSI40
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_1
    <td>CSI20 <td>  N/A <td>    CSI40 <td>  CSI20 <td>  CSI20 <td>  N/A <td>    CSI40 <td>  CSI20
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_2
    <td>N/A <td>    CSI40 <td>  CSI20 <td>  N/A <td>    N/A <td>    CSI40 <td>  CSI20 <td>  N/A 
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_3
    <td>CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI40 <td>  CSI40
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_4
    <td>CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20 <td>  CSI20
    <tr><td>R_WM_VIN_CSI2F_MODE_CONFIG_5
    <td>N/A <td>    N/A <td>    N/A <td>    N/A <td>    N/A <td>    N/A <td>    N/A <td>    N/A
    </table>
*/
typedef enum
{
    R_WM_VIN_CSI2F_MODE_CONFIG_0 = 0,/**< Config mode 0 see table*/
    R_WM_VIN_CSI2F_MODE_CONFIG_1 = 1,/**< Config mode 1 see table*/
    R_WM_VIN_CSI2F_MODE_CONFIG_2 = 2,/**< Config mode 2 see table*/
    R_WM_VIN_CSI2F_MODE_CONFIG_3 = 3,/**< Config mode 3 see table*/
    R_WM_VIN_CSI2F_MODE_CONFIG_4 = 4,/**< Config mode 4 see table*/
    R_WM_VIN_CSI2F_MODE_CONFIG_5 = 5,/**< Config mode 5 see table*/
    
    R_WM_VIN_CSI2F_MODE_CONFIG_LAST, /**< Last enum. Used for boundary check */
} r_wm_CapVInConfig_t;

/*******************************************************************************/
/** 
    @enum   r_wm_CapMIPILane_t
    @brief  List of possible Lane mode for MIPI input.
*/
typedef enum
{
    R_WM_MIPI_CSI_LANE_1 =  0x01, /**< Use 1 Lane*/
    R_WM_MIPI_CSI_LANE_2 =  0x02, /**< Use 2 Lanes*/
    R_WM_MIPI_CSI_LANE_4 =  0x04, /**< Use 4 Lanes*/
    
    R_WM_MIPI_CSI_LANE_LAST     /**< Used for boundary check*/
} r_wm_CapMIPILane_t;

/*******************************************************************************/
/** 
    @enum  r_wm_CapMIPILaneMBps_t
    @brief List of possible Mega Bitperseconds for the MIPI-CSI2 configuration
*/
typedef enum
{
    R_WM_MIPI_CSI_MBPS_80     = 0,  /**<Select   80 MPS*/
    R_WM_MIPI_CSI_MBPS_90     = 1,  /**<Select   90 MPS*/
    R_WM_MIPI_CSI_MBPS_100    = 2,  /**<Select  100 MPS*/
    R_WM_MIPI_CSI_MBPS_110    = 3,  /**<Select  110 MPS*/
    R_WM_MIPI_CSI_MBPS_120    = 4,  /**<Select  120 MPS*/
    R_WM_MIPI_CSI_MBPS_130    = 5,  /**<Select  130 MPS*/
    R_WM_MIPI_CSI_MBPS_140    = 6,  /**<Select  140 MPS*/
    R_WM_MIPI_CSI_MBPS_150    = 7,  /**<Select  150 MPS*/
    R_WM_MIPI_CSI_MBPS_160    = 8,  /**<Select  160 MPS*/
    R_WM_MIPI_CSI_MBPS_170    = 9,  /**<Select  170 MPS*/
    R_WM_MIPI_CSI_MBPS_180    = 10, /**<Select  180 MPS*/
    R_WM_MIPI_CSI_MBPS_190    = 11, /**<Select  190 MPS*/
    R_WM_MIPI_CSI_MBPS_205    = 12, /**<Select  205 MPS*/
    R_WM_MIPI_CSI_MBPS_220    = 13, /**<Select  220 MPS*/
    R_WM_MIPI_CSI_MBPS_235    = 14, /**<Select  235 MPS*/
    R_WM_MIPI_CSI_MBPS_250    = 15, /**<Select  250 MPS*/
    R_WM_MIPI_CSI_MBPS_275    = 16, /**<Select  275 MPS*/
    R_WM_MIPI_CSI_MBPS_300    = 17, /**<Select  300 MPS*/
    R_WM_MIPI_CSI_MBPS_325    = 18, /**<Select  325 MPS*/
    R_WM_MIPI_CSI_MBPS_350    = 19, /**<Select  350 MPS*/
    R_WM_MIPI_CSI_MBPS_400    = 20, /**<Select  400 MPS*/
    R_WM_MIPI_CSI_MBPS_450    = 21, /**<Select  450 MPS*/
    R_WM_MIPI_CSI_MBPS_500    = 22, /**<Select  500 MPS*/
    R_WM_MIPI_CSI_MBPS_550    = 23, /**<Select  550 MPS*/
    R_WM_MIPI_CSI_MBPS_600    = 24, /**<Select  600 MPS*/
    R_WM_MIPI_CSI_MBPS_650    = 25, /**<Select  650 MPS*/
    R_WM_MIPI_CSI_MBPS_700    = 26, /**<Select  700 MPS*/
    R_WM_MIPI_CSI_MBPS_750    = 27, /**<Select  750 MPS*/
    R_WM_MIPI_CSI_MBPS_800    = 28, /**<Select  800 MPS*/
    R_WM_MIPI_CSI_MBPS_850    = 29, /**<Select  850 MPS*/
    R_WM_MIPI_CSI_MBPS_900    = 30, /**<Select  900 MPS*/
    R_WM_MIPI_CSI_MBPS_950    = 31, /**<Select  950 MPS*/
    R_WM_MIPI_CSI_MBPS_1000   = 32, /**<Select 1000 MPS*/
    R_WM_MIPI_CSI_MBPS_1050   = 33, /**<Select 1050 MPS*/
    R_WM_MIPI_CSI_MBPS_1100   = 34, /**<Select 1100 MPS*/
    R_WM_MIPI_CSI_MBPS_1150   = 35, /**<Select 1150 MPS*/
    R_WM_MIPI_CSI_MBPS_1200   = 36, /**<Select 1200 MPS*/
    R_WM_MIPI_CSI_MBPS_1250   = 37, /**<Select 1250 MPS*/
    R_WM_MIPI_CSI_MBPS_1300   = 38, /**<Select 1300 MPS*/
    R_WM_MIPI_CSI_MBPS_1350   = 39, /**<Select 1250 MPS*/
    R_WM_MIPI_CSI_MBPS_1400   = 40, /**<Select 1400 MPS*/
    R_WM_MIPI_CSI_MBPS_1450   = 41, /**<Select 1450 MPS*/
    R_WM_MIPI_CSI_MBPS_1500   = 42, /**<Select 1500 MPS*/
    
    R_WM_MIPI_CSI_MBPS_LAST /**< Lst Enum. Use for boundary check */
} r_wm_CapMIPILaneMBps_t;

/*******************************************************************************/
/** 
    @struct  r_wm_CapMIPIConf_t
    @brief   MIPI configuration parameters.

    TODO: Modify the VIN so that the range are not hardcoded in WM.
          Must be defined in VIN headers.
   
*/
typedef struct
{
    r_wm_CapMIPILane_t      Lane;       /**< Nb of MIPI lane, @ref r_wm_CapMIPILane_t*/
    r_wm_CapMIPILaneMBps_t  LaneMBps;   /**< MBit Per Second, @ref r_wm_CapMIPILaneMBps_t.*/
} r_wm_CapMIPIConf_t;

/*******************************************************************************/
/** 
    @struct  r_wm_Capture_s
    @brief   The type describes the settings of a video capturing surface. 
            The video capturing surface is always associated with a window surface. 
*/

struct r_wm_Capture_s
{
    uint32_t                CaptUnit;     /**< The Video Channel to be used for capturing.*/
    r_wm_Window_t         * Window;       /**< The member is a pointer to the associated window.
                                               The window has to match the requirements of the captured video;*/
    r_wm_CapMode_t          Mode;         /**< specifies the capturing mode, @ref r_wm_CapMode_t*/
    r_wm_CapSrc_t           CapSource;    /**< Source of the Video Capture. see @ref r_wm_CapSrc_t*/
    r_wm_CapMIPIConf_t      MIPIConfig;   /**< Configuration of the MIPI interface, give the Lane and MBps. see @ref r_wm_CapMIPIConf_t*/
    r_wm_CapVInConfig_t     VInConfig;    /**< Vin configuration, @ref r_wm_CapVInConfig_t*/
    uint32_t                StartX;       /**< This is the X starting position in the video.*/
    uint32_t                StartY;       /**< This is the Y starting position for the first field*/
    uint32_t                StrideX;      /**< The parameter specifies the stride in the frame buffer.*/
    uint32_t                Width;        /**< This is the width of the video*/
    uint32_t                Height;       /**< Height of the video*/
    uint32_t                ScaledWidth;  /**< video will be scaled to this width*/
    uint32_t                ScaledHeight; /**< video will be scaled to this height*/
    uint8_t                 Alpha;        /**< Transparency factor of the captured image*/
    struct r_wm_Capture_s * Next;         /**< pointer to the next capture surface. Internal use only*/
};

/*******************************************************************************/
/** 
    @struct r_wm_Capture_t
    @brief  forward declaration for r_wm_Capture_s
*/
typedef struct r_wm_Capture_s r_wm_Capture_t;

/***********************************************************
  Section: Global API functions
*/


/***********************************************************/
/**
  @defgroup Device WM Device functions
  @brief The section describes user driver functions, which are related to a specific functionality 
         of the macro itself. They are required for general use of the WM driver, 
  @{
*/

/***********************************************************/
/**
  @function R_WM_DevInit
  @brief    Init WM unit.
  
  Description:
  This function initializes the user driver for the given display unit. 
  The driver makes sure, that the macro is set into a default configuration. 
    
  @param[in] Unit   The parameter specifies the Display unit index
                    The window manager can support more than one physical screen 
                    Valid values are defined by <R_WM_DEV_*>
                    The number of valid devices is <R_WM_DEV_NUM>
  @return    @ref r_wm_Error_t.
*/
r_wm_Error_t R_WM_DevInit (const uint32_t Unit);

/***********************************************************/
/** 
  @function R_WM_DevDeinit
  @brief    DeInit WM unit.

  Description:
  This function deinitializes the driver and the hardware. 
  In case the function is called for an instance of the macro, 
  which has not been initialized before, the function shall return an error. 
  
  @param[in]  Unit   see @ref R_WM_DevInit description
  
  @return     @ref r_wm_Error_t.
*/
r_wm_Error_t R_WM_DevDeinit (const uint32_t Unit);

/***********************************************************/
/** 
  @function R_WM_DevInfoGet
  @brief    Get information of screen and window parameters.

  Parameters:
  @param[in]   Unit           see @ref R_WM_DevInit description
  @param[out]  LayerNum       pointer to a variable to return number of usable layers
  @param[out]  PitchMax       pointer to a variable to return maximum pitch of a layer. If 0 is returned then a pitch is not supported.
  @param[out]  WidthMax       pointer to a variable to return maximum width of a layer
  @param[out]  HeightMax      pointer to a variable to return maximum height of a layer
  @param[out]  ScreenColorFmt pointer to an output variable, return the Screen color format
  @param[out]  VSPUnit        pointer to an output variable, return the VSP Unit mapped to the DU  if any, else -1
  @param[out]  VSPDULayer     pointer to an output variable, return theDU Layer linked to the VSP output else -1.
  
  @return @ref r_wm_Error_t.
*/
r_wm_Error_t R_WM_DevInfoGet (const uint32_t       Unit,
                              uint32_t           * LayerNum,
                              uint32_t           * PitchMax,
                              uint32_t           * WidthMax,
                              uint32_t           * HeightMax,
                              r_wm_OutColorFmt_t * ScreenColorFmt,
                              int32_t            * VSPUnit,
                              int32_t            * VSPDULayer
                              );

/***********************************************************/
/** 
  @function R_WM_VspdInfoGet
  @brief    Get VSPD information for the given unit.

  Parameters:
  @param[in]  Unit           see @ref R_WM_DevInit description
  @param[in]  VspdInfo       pointer to a variable to return the info 
 
  @return @ref r_wm_Error_t.

*/
uint32_t R_WM_VspdInfoGet(const uint32_t Unit, r_wm_VspdInfo_t *VspdInfo); 

/***********************************************************/
/**
  @function  R_WM_GetVersionString
  @brief     Returns the version of the Window Manager.
  
  @return version string of this WM driver
*/
const int8_t * R_WM_GetVersionString (void);

/***********************************************************/
/**
  @function  R_WM_DevEventRegister
  @brief  Register for retrieving the notification on an event.
  
  Only the external events registered with this function will
  be received by the device callback function.
  
  @param[in]  Unit      @ref R_WM_DevInit
  @param[in]  EventId   The ID of the event to be registered for receiving
  @param[in]  Arg       Generic argument if applicable
  
  Generic argument values:

  - R_WM_EVENT_VBLANK       - any (ignored) 
  - R_WM_EVENT_HBLANK       - any (ignored) 
  - R_WM_EVENT_RASTER       - scan line number on which the interrupt will trigger
  - R_WM_EVENT_UNDERRUN     - any (ignored)
  - R_WM_EVENT_TEXTURESWAP  - Texture Index. (or Z Pos)
  
  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DevEventRegister (const uint32_t       Unit,
                                    const r_wm_EventId_t EventId,
                                    const uint32_t       Arg
                                    );

/***********************************************************/
/**
  @function  R_WM_DevWaitForEvent
  @brief  Wait for the given Event to occur.
  
  @param[in]  Id        For VOut Device, represent the Unit number. See description of r_wm_dev_num_t for VOut Device
                        In case of Texture Device, the Texture Index of the given Texture surface must be given.
  @param[in]  EventId   The ID of the event to be registered for receiving

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DevWaitForEvent (const uint32_t       Id,
                                   const r_wm_EventId_t EventId
                                  );

/**
  @}
*/

/***********************************************************/
/**
  @defgroup Screen WM Screen functions
  @brief A screen is a physical video output unit. Those functions are used to configure
         a specific video output unit.
  @{
*/

/***********************************************************/
/** 
  @function R_WM_ScreenDUTimingGet
  @brief    Get the Display Timing

  Parameters:
  @param[in]   Unit           see @ref R_WM_DevInit description
  @param[out]  ScreenTiming   pointer to a structure of type @ref ScreenTiming
  
  @return @ref r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDUTimingGet (const uint32_t       Unit,
                                    r_ddb_Timing_t * ScreenTiming
                                    );

/***********************************************************/
/**
  @function  R_WM_ScreenVSPEnable
  @brief     Enable the use of VSPD Unit fro a given DU.
             Return an error if the corresponding unit was not initialised in DU mode.

  @param[in] DispUnit   Display Unit number
  @param[in] VspUnit    VSP Unit number
  @param[in] DispLayer  display layer where the output of the VSPD will be shown
  
  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenVSPEnable (const uint32_t DispUnit,
                                   const uint32_t VspUnit, 
                                   const uint32_t DispLayer
                                   );

/***********************************************************/
/**
  @function  R_WM_ScreenVSPInitialise
  @brief     Enable the use of VSPD in DU mode.
  
  Mapped the given VSPD Unit to the specified Display unit layer. It also set
  the Width, Height and colour format of the VSPD output as well as its position on screen.
  

  @param[in]  DispUnit     Display unit
  @param[in]  VspdUnit     VSP Unit
  @param[in]  DispLayer    Display unit layer to which the VSP is mapped to.E.g.:VSPD0 to DU0 L0 or VSPD0 to DU2 L0, etc... 
                           See VSP limitiations
  @param[in]  OutFmt       @ref r_wm_WinColorFmt_t. At the moment per default to ARGB8888
  @param[in]  PosX         X position on the main screen of the VSPD output
  @param[in]  PosY         Y position on the main screen of the VSPD output
  @param[in]  Width        Width of the VSPD output
  @param[in]  Height       Height of the VSPD output

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenVSPInitialise (const uint32_t           DispUnit,
                                       const uint32_t           VspUnit, 
                                       const uint32_t           DispLayer,
                                       const r_wm_WinColorFmt_t OutFmt,
                                       const int32_t            PosX,
                                       const int32_t            PosY, 
                                       const uint32_t           Width,
                                       const uint32_t           Height
                                       );

/***********************************************************/
/**
  @function  R_WM_ScreenVSPDisable
  @brief     Disable the use of VSPD Unit.
  
  Disable the DU Layer.
  Return an error if the corresponding unit was not initialised in DU mode.

  @param[in]  DispUnit      Display unit
  @param[in]  VspUnit       VSP Unit
  @param[in]  DispLayer     display Layer mapped to the VSP Unit output

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenVSPDisable (const uint32_t DispUnit,
                                    const uint32_t VspUnit,
                                    const uint32_t DispLayer
                                    );

/***********************************************************/
/**
  @function  R_WM_ScreenVSPDeInitialise
  @brief     Disable the use of VSPD in DU mode.
  
  Mapped the given VSPD Unit to the specified Display unit layer. It also set
  the Width, Height and colour format of the VSPD output as well as its position on screen.
  

  @param[in]  DispUnit    see @ref R_WM_DevInit description
  @param[in]  VspdUnit    VSP Unit

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenVSPDeInitialise (const uint32_t DispUnit,
                                         const uint32_t VspUnit
                                         );

/***********************************************************/
/**
  @function  R_WM_ScreenBgColorSet
  @brief     Set the screen background color that is seen if no window 
            (or a transparent one) is on top of it. 
  
  If the selected screen does not support a background color, 
  the function will return with an error.

  @param[in]  Unit      see @ref R_WM_DevInit description
  @param[in]  Red       The red color component of the background color.
  @param[in]  Green     The green color component of the background color.
  @param[in]  Blue      The blue color component of the background color.

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenBgColorSet (const uint32_t Unit,
                                    const uint8_t  Red,
                                    const uint8_t  Green,
                                    const uint8_t  Blue
                                    );

/***********************************************************/
/**
  @function  R_WM_ScreenEnable
  @brief     Switch on the display.

  @param[in]  Unit   see @ref R_WM_DevInit description

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenEnable (const uint32_t Unit);

/***********************************************************/
/**
  @function  R_WM_ScreenDisable
  @brief     Switch off the display.

  @param[in]  Unit      see @ref R_WM_DevInit description

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ScreenDisable (const uint32_t Unit);

/***********************************************************/
/** 
  @function R_WM_ScreenCmmSetProperty
  @brief  This function configures the display output CMM.
  
  It is used to configure the CMM nut also to enable/Disable 
  CMM functions.
  
  @param[in]  Unit        WM device, @ref R_WM_DevInit description
  @param[in]  Prop        The propertry to be changed. See @ref r_wm_DispProperty_t.
  @param[in]  PropData    Pointer to the data (settings or mode) for the given property
  
  @return  @ref r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenCmmSetProperty (const uint32_t Unit, r_wm_ScreenProperty_t Prop, void * PropData); 

/***********************************************************/
/**
  @function R_WM_ScreenCmmGetProperty
  @brief    This function get the the data of the configuration of the display output CMM.

  @param[in]  Unit        WM device, @ref R_WM_DevInit description
  @param[in]  Prop        The propertry to be queried. See @ref r_wm_Property_t.
  @param[in]  PropData    Pointer to the data (settings or mode) of the given property

  @return  @ref r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenCmmGetProperty (const uint32_t Unit, r_wm_ScreenProperty_t Prop, void * PropData); 

/***********************************************************/
/**
    @function R_WM_ScreenDocIntRegister
    @brief    This function registers a semaphore for the given event (interrupt).
 
    @param[in]  Unit     WM device, @ref R_WM_DevInit description.
    @param[in]  IntType  Type of the DOC interrupt, see @ref r_wm_DocIntType_t
 
    @return  @see r_wm_Error_t.
 */
r_wm_Error_t R_WM_ScreenDocIntRegister(const uint32_t Unit, r_wm_DocIntType_t IntType);

/***************************************************************************/
/**
  @function R_WM_ScreenDocIntWait
  @brief    This function waits for the specified event (interrupt occurance) 
  
  This is using internally the wait for semaphore mechanism to avoid any while-loops

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  @param[in]  IntType  Type of the DOC interrupt, see @ref r_wm_DocIntType_t

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocIntWait (const uint32_t Unit, r_wm_DocIntType_t IntType);

/***************************************************************************/
/**
  @function R_WM_ScreenDocDeInit
  @brief    This de-initialises the DOC "driver" 

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocDeInit(const uint32_t Unit);

/***************************************************************************/
/**
  @function R_WM_ScreenDocParamSet
  @brief    This function sets DOC parameter.

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  @param[in]  Param    Pointer to Doc parameter structure, @ref r_wm_DocParam_t.

  @return  @see r_wm_Error_t.
 */
r_wm_Error_t R_WM_ScreenDocParamSet (const uint32_t Unit,
                                     const r_wm_DocParam_t *Param);

/***************************************************************************/
/**
  @function R_WM_ScreenDocColorRAMSet
  @brief  This function sets the reference colors of DOC.
  
  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  @param[in]  Offset   Index of the first updated color.
  @param[in]  Size     Number of table entries.
  @param[in]  Table    Table containing the 2-bpp CLUT2 indices of the reference colors.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocRefColorSet (const uint32_t   Unit,
                                        const uint32_t   Offset,
                                        const uint32_t   Size,
                                        const uint32_t * Table
                                        );

/***************************************************************************/
/**
  @function R_WM_ScreenDocMonitorAreaSet
  @brief    This function sets monitor area.

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  @param[in]  Param    Monitor area.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocMonitorAreaSet (const uint32_t Unit,
                                           const r_wm_DocMonArea_t *Param);

/***************************************************************************/
/**
  @function R_WM_ScreenDocCheckEnable
  @brief    This function enable video output check.

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  @param[in]  MonArea  Monitor area bit mask.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocCheckEnable (const uint32_t Unit,
                                        const uint16_t MonArea);

/***************************************************************************/
/**
  @function R_WM_ScreenDocCheckDisable
  @brief    This function disable video output check.

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  @param[in]  MonArea  Monitor area bit mask.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocCheckDisable (const uint32_t Unit,
                                         const uint16_t MonArea);

/***************************************************************************/
/**
  @function R_WM_ScreenDocStatusClear
  @brief    This function clears the DOC status.

  @param[in]  Unit     WM device, @ref R_WM_DevInit description.
  
  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocStatusClear (const uint32_t   Unit);

/***************************************************************************/
/**
  @function R_WM_ScreenDocStatusGet
  @brief    This function reads and returns the DOC status.

  @param[in]   Unit     WM device, @ref R_WM_DevInit description.
  @param[out]  Status   Pointer to status.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocStatusGet (const uint32_t   Unit,
                                            uint32_t *Status);

/***************************************************************************/
/**
  @function R_WM_ScreenDocMonEnable
  @brief    This function enable active monitor.

  @param[in]  Unit       WM device, @ref R_WM_DevInit description.
  @param[in]  UpperTime  Upper detection time.
  @param[in]  LowerTime  Lower detection time.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocMonEnable (const uint32_t Unit,
                                      const uint16_t UpperTime,
                                      const uint16_t LowerTime);

/***************************************************************************/
/**
  @function R_WM_ScreenDocMonDisable
  @brief    This function disables active monitor.

  @param[in]  Unit       WM device, @ref R_WM_DevInit description.

  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocMonDisable (const uint32_t Unit);

/***************************************************************************/
/**
  @function R_WM_ScreenDocIntcEnable
  @brief    This function enables the given DOC interrupt.

  Note:
  Setting IntType to R_WM_DOC_INTC_DISABLE disables all the interrupts.

  @param[in]  Unit        WM device, @ref R_WM_DevInit description.
  @param[in]  IntType     DOC Interrupt type.
  
  @return  @see r_wm_Error_t.
*/
r_wm_Error_t R_WM_ScreenDocIntcEnable (const uint32_t Unit,
                                       const r_wm_DocIntType_t IntType);

/**
  @}
*/

/***********************************************************/
/**
  @defgroup Windows WM Window functions
  
  @brief  Functions that handle WM Window
  
  A window is an area with graphical content, which is placed 
  on a screen(R_WM_SURFACE_FB) or saved in memory (R_WM_SURFACE_TEXTURE).
  
  Windows which are displayed, may cover the whole screen, part of the screen, but 
  a window cannot be bigger than the screen.

  It is possible to stack windows and to define transparency for a window. 
  Windows dsiplayed on a WM device, cannot have the same Z position, as the Z position 
  correspond to a video output Layer.
  
  @{

*/

/***********************************************************/
/**
  @function  R_WM_WindowCreate
  @brief     Create a window as specified in the Window parameter.
  
  Depending on the type it will the window will be for the given screen Unit or 
  for memory
  
  For variable locations of r_wm_Window_t that are not initialized 
  during startup, e.g. local variables or allocated variables, please
  make sure to initialize all members of the struct.
  Unused values may be set to zero.
  For example: (code)
  memset(&Window, 0, sizeof(r_wm_Window_t))
  (end)

  If the r_wm_WinBufAllocMode_t is R_WM_WINBUF_ALLOC_EXTERNAL 
  the pointer Buffer of the window structure has to point to 
  an array of BufNum elements of r_wm_WinBuffer_t type.
  
  Alternatively the Buffer does not need to be set yet. 
  It can be set later by r_wm_WindowExternalBufSet.

  If the r_wm_WinBufAllocMode_t is R_WM_WINBUF_ALLOC_INTERNAL
  the function will allocate the Buffer data for each buffer itself. 
  Buffer must be set to NULL.

  The Next pointer value is set by the function; any value 
  in it will be ignored. 
  
  The window will not be visible until it is enabled. 

  @param[in]  Unit      Can refer to the WM Device, see @ref R_WM_DevInit
  @param[in]  Window    This is a pointer to a @ref r_wm_Window_t structure. 
             The structure has to be filled by the application 
             before calling the function.
  
  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_WindowCreate (const uint32_t   Unit,
                                r_wm_Window_t  * Window
                               );

/***********************************************************
  @function  R_WM_WindowCreateWithOffset
  @brief     This is functionally equivalent to @ref R_WM_WindowCreate, but it accepts
  two additional parameters: the (x,y) offsets into the source memory buffer.

  @param[in]  Unit   - Can refer to the WM Device, see @ref R_WM_DevInit, or be the Texture ID.
  @param[in]  Window - This is a pointer to an @ref r_wm_Window_t structure.
             The structure has to be filled by the application
             before calling the function.
  @param[in]  OffX   - X offset into the source memory buffer.
  @param[in]  OffY   - Y offset into the source memory buffer.

  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_WindowCreateWithOffset (const uint32_t   Unit,
                                          r_wm_Window_t  * Window,
                                          const uint32_t   OffX,
                                          const uint32_t   OffY
                                         );

/***********************************************************/
/**
  @function  R_WM_WindowDelete
  @brief     The function deletes the specified window. 
  
  All internally allocated data buffer will be freed by the function. 

  @param[in]  Unit    @ref R_WM_DevInit description
  @param[in]  Window  This is a window's structure r_wm_Window_t pointer. @ref r_wm_Window_t
  
  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_WindowDelete (const uint32_t   Unit,
                                r_wm_Window_t  * Window
                                );

/***********************************************************/
/**
  @function   R_WM_WindowCreateFromHandle
  @brief      The function gets the information of a specific surface. 
  
  It will fill the given Window parameter with the obtain information.
  e.g.: Width, Height, colour format, FB...
  And allocate the VMR.

  @param[out]  Window     Output: Pointer to window's structure @ref r_wm_Window_t pointer
  
  @return  @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_WindowCreateFromHandle (r_wm_Window_t * Window);

/***********************************************************/
/**
  @function   R_WM_WindowFreeFromHandle
  @brief      Delete a surface created from a handle.
  
  The function free the VMR and other buffers allocated by the Application.
  It does not free the layer on the server side.
  It shall be used only if the surface was created from a handle.

  @param[out]  Window      Pointer to window's structure @ref r_wm_Window_t
  
  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowFreeFromHandle (r_wm_Window_t * Window);

/***********************************************************/
/**
  @function   R_WM_WindowEnable
  @brief      Enable the window. 
  
  The window will be visible on the screen after calling this function.

  This function sends a message to the WM Server to enable the window
  on screen.
  It Returns an error if the window is not of type R_WM_SURFACE_FB.

  @param[in]  Unit    see @ref R_WM_DevInit
  @param[in]  Window  pointer to a window's structure of type @ref r_wm_Window_t

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowEnable  (const uint32_t   Unit,
                                 r_wm_Window_t  * Window
                                );

/***********************************************************/
/**
  @function   R_WM_WindowDisable
  @brief      Disable the window. 
  
  The window will be invisible on the screen after calling this function.

  This function sends a message to the WM Server to disable the window
  on screen.
  It returns an error if the window is not of type R_WM_SURFACE_FB.

  @param[in]  Unit    see @ref R_WM_DevInit
  @param[in]  Window  Pointer to a structure of type @ref r_wm_Window_t.

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowDisable (const uint32_t   Unit,
                                 r_wm_Window_t  * Window
                                );

/***********************************************************/
/**
  @function   R_WM_WindowMove
  @brief      Move the window to the specified position.

  This function sends the requests to the WM server which will handle the move.

  @param[in]  Unit    see @ref R_WM_DevInit
  @param[in]  Window  Pointer to a structure of type @ref r_wm_Window_t.
  @param[in]  PosX    Specify the new X position of the window on the screen.
  @param[in]  PosY    Specify the new Y position of the window on the screen.
  @param[in]  PosZ    Specify the new Z position of the window on the screen. (Ignored)

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowMove (const uint32_t   Unit,
                              r_wm_Window_t  * Window,
                              const int32_t    PosX,
                              const int32_t    PosY,
                              const int32_t    PosZ
                              );

/***********************************************************
  @function: R_WM_WindowMoveWithOffset

  @brief This is functionally equivalent to <R_WM_WindowMove>, but it accepts
  two additional parameters: the (x,y) offsets into the source memory buffer.

  @param[in]  Unit           - See description of @ref R_WM_DevInit
  @param[in]  Window         - This is a window's structure @ref r_wm_Window_t pointer
  @param[in]  PosX/PosY/PosZ - These parameters specify the new position of the window on the screen.
  @param[in]  OffX/OffY      - X and Y offsets into the source memory buffer.

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowMoveWithOffset (const uint32_t   Unit,
                                        r_wm_Window_t  * Window,
                                        const int32_t    PosX,
                                        const int32_t    PosY,
                                        const int32_t    PosZ,
                                        const uint32_t   OffX,
                                        const uint32_t   OffY
                                        );

/***********************************************************/
/**
  @function   R_WM_WindowResize
  @brief      Resizes the window.

  @param[in]  Unit    see @ref R_WM_DevInit
  @param[in]  Window  Pointer to a structure of type @ref r_wm_Window_t.
  @param[in]  Pitch   Specify the new pitch of the window.
  @param[in]  Width   Specify the new width of the window.
  @param[in]  Height  Specify the new height of the window.

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowResize  (const uint32_t   Unit,
                                 r_wm_Window_t  * Window,
                                 const uint32_t   Pitch,
                                 const uint32_t   Width,
                                 const uint32_t   Height
                                );

/***********************************************************
  @function R_WM_WindowResizeWithOffset
  @brief    This is functionally equivalent to <R_WM_WindowResize>, but it accepts
    two additional parameters: the (x,y) offsets into the source memory buffer.

  @param[in]  Unit                - See description of @ref R_WM_DevInit
  @param[in]  Window              - This is a window's structure @ref r_wm_Window_t pointer
  @param[in]  Pitch/Width/Height  - These parameters specify the new geometry of the window.
  @param[in]  OffX/OffY           - X and Y offsets into the source memory buffer.

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowResizeWithOffset  (const uint32_t   Unit,
                                           r_wm_Window_t  * Window,
                                           const uint32_t   Pitch,
                                           const uint32_t   Width,
                                           const uint32_t   Height,
                                           const uint32_t   OffX,
                                           const uint32_t   OffY
                                );

/***********************************************************/
/**
  @function R_WM_WindowColorFmtSet
  @brief    Sets the color format of the window.

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.
  @param[in]  ColorFmt  Window color format, see r_wm_WinColorFmt_t

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowColorFmtSet (const uint32_t             Unit,
                                     r_wm_Window_t            * Window,
                                     const r_wm_WinColorFmt_t   ColorFmt
                                    );

/***********************************************************/
/**
  @function  R_WM_WindowAlphaSet
  @brief     Change the window's alpha value.

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.
  @param[in]  Alpha     New alpha value of the window.
  
  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowAlphaSet (const uint32_t   Unit,
                                  r_wm_Window_t  * Window,
                                  const uint8_t    Alpha
                                 );

/***********************************************************/
/**
  @function  R_WM_WindowPremultipliedAlphaEnable
  @brief     Enable the window's premultiplied alpha mode.

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.
  
  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowPremultipliedAlphaEnable (const uint32_t   Unit,
                                                  r_wm_Window_t  * Window
                                                  );

/***********************************************************/
/**
  @function  R_WM_WindowPremultipliedAlphaDisable
  @brief     Disable the window's premultiplied alpha mode.

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.
  
  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowPremultipliedAlphaDisable (const uint32_t   Unit,
                                                   r_wm_Window_t  * Window
                                                   );

/***********************************************************/
/**
  @function  R_WM_WindowSwap
  @brief     Swap the surface's framebuffer
  
  If the window is a multi-buffer window, the background buffer 
  is switched to the window surface (@ref r_wm_WinBufStatus_t). 

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.
    
  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowSwap (const uint32_t   Unit,
                              r_wm_Window_t  * Window
                              );

/***********************************************************/
/**
  @function  R_WM_WindowSyncSwap
  @brief     Requests a Sync semaphore, Initiates a Swap, waits for the semaphores.
             It returns only when the swap actually occurs. 
             The user can ask immediately after for a new buffer

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.

  @return  @ref r_wm_Error_t 
*/
r_wm_Error_t R_WM_WindowSyncSwap (const uint32_t   Unit,
                                  r_wm_Window_t  * Window
                                );

/***********************************************************/
/**
  @function  R_WM_WindowNewDrawBufGet
  @brief     Returns the next free buffer of the specified window.

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Window    Pointer to a structure of type r_wm_Window_t.

  @return  
    - Address of the next frame buffer, which can be used for drawing operations.
    - Zero if no free buffer is available.
*/
void *R_WM_WindowNewDrawBufGet (const uint32_t   Unit,
                                r_wm_Window_t  * Window
                                );

/***********************************************************/
/**
  @function  R_WM_WindowExternalBufSet
  @brief     Set the framebuffer address for windows with externally allocated buffers
  
  The window must have been created with the <r_wm_WinBufAllocMode_t> R_WM_WINBUF_ALLOC_EXTERNAL.

  @param[in]  Unit          see @ref R_WM_DevInit
  @param[in]  Window        Pointer to a structure of type r_wm_Window_t.
  @param[in]  FbBuf         MemBlock array. see @ref r_mmgr_MemBlock_t
  @param[in]  BufNum        Number of buffers in the array
  @param[in]  ColorFormat   Color format of the buffers

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_WindowExternalBufSet (const uint32_t              Unit,
                                        r_wm_Window_t             * Window,
                                        r_mmgr_MemBlock_t        ** FbBuf,
                                        const uint32_t              BufNum,
                                        const r_wm_WinColorFmt_t    ColorFormat
                                       );

/***********************************************************/
/**
  @function  R_WM_WindowClutSet
  @brief     Sets the colour lookup table. 
  
  Only applicable for the windows with CLUT colour modes specified, i.e. a window mapped to a VSP Layer.
  
  @param[in]  Unit          see @ref R_WM_DevInit
  @param[in]  Window        Pointer to a structure of type r_wm_Window_t.
  @param[in]  NumEntries    Number of the color lookup-table entries
  @param[in]  Clut          Color lookup-table pointer, @ref r_wm_ClutEntry_t 
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_WindowClutSet (const uint32_t           Unit,
                                 r_wm_Window_t          * Window,
                                 const uint32_t           NumEntries,
                                 const r_wm_ClutEntry_t * Clut
                                );

/**
  @}
*/

/***********************************************************/
/**
  @defgroup VinCapture WM Video Capture functions
  @brief    WM functions handling video capture surfaces
  
  @{
  
*/
#ifndef _WIN32
/***********************************************************/
/**
  @function  R_WM_CaptureCreate
  @brief     Create a video capture surface inside a specific window on the screen Unit. 
  
  The pointer Window of the capture structure has to point to a valid window,
  which needs to be of the 'frame buffer' type.
  It is also the responsibility of the caller to ensure
  that the window is suitable for the desired video capturing parameters. 
  The capturing surface will not be visible until it is enabled. 

  @param[in]  Unit          see @ref R_WM_DevInit
  @param[in]  Capture       Pointer to a structure of type r_wm_Capture_t.
                            The structure has to be filled by the application before calling the function.

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_CaptureCreate (const uint32_t   Unit,
                                 r_wm_Capture_t * Capture
                                );


/***********************************************************/
/**
  @function  R_WM_CaptureDelete
  @brief     Delete the specified capturing surface. 
  
  It will not delete the window, which is used for the capturing.

  @param[in]  Unit          see @ref R_WM_DevInit
  @param[in]  Capture       Pointer to a structure of type r_wm_Capture_t.

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_CaptureDelete (const uint32_t   Unit,
                                 r_wm_Capture_t * Capture
                                );

/***********************************************************/
/**
  @function  R_WM_CaptureDelete
  @brief     Enable the video capturing surface and start the capturing. 
  
  The capturing is visible inside the specified window.

  @param[in]  Unit          see @ref R_WM_DevInit
  @param[in]  Capture       Pointer to a structure of type r_wm_Capture_t.

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_CaptureEnable (const uint32_t   Unit,
                                 r_wm_Capture_t * Capture
                                );

/***********************************************************/
/**
  @function  R_WM_CaptureDisable
  @brief     Disable the video capturing. The last frame will remain in the window's framebuffer.

  @param[in]  Unit          see @ref R_WM_DevInit
  @param[in]  Capture       Pointer to a structure of type r_wm_Capture_t.

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_CaptureDisable (const uint32_t   Unit,
                                  r_wm_Capture_t * Capture
                                 );
#endif

/**
  @}
*/

/***********************************************************/
/**
  @defgroup WMTexture WM Texture Synchronisation functions
  @brief    Functions used to synchornised textures with multiple buffered.
  
  Those functions are useful when 1 task is rendering a double buffered texture
  and another task is using.
  It allows the tasks to synchronised.
  
  @{
  
*/

/***********************************************************/
/**
  @function  R_WM_TextureWaitForSync
  @brief     Wait for a Sync with a given texture

  @param[in]  TextureId       ID of the texture to sync against
  @param[in]  PhysAddr        Physical address of the texture that can be used.

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_TextureWaitForSync (const uint32_t   TextureId,
                                      uint64_t       * PhysAddr
                                      );

/***********************************************************/
/**
  @function  R_WM_TextureLock
  @brief     Lock the texture to the current application.
  
  A texture can only be locked once and an error is returned if it is 
  already in use.
  
  @param[in]  TextureId       ID of the texture
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_TextureLock (const uint32_t TextureId);

/***********************************************************/
/**
  @function  R_WM_TextureUnLock
  @brief     UnLock the texture and the current application.
  
  A texture cannot be freed / deleted if still in use by another application.
  
  @param[in]  TextureId       ID of the texture
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_TextureUnLock (const uint32_t TextureId);

/**
  @}
*/

/***********************************************************/
/**
  @defgroup DISCOM/DOC WindowManager DISCOM and DOC functions
  @brief    WM functions handling output verification 
  
  @{
  
*/
/***********************************************************/
/**
  @function  R_WM_DiscomEnable
  @brief     Enable/Disable the .
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
  @param[in]  EnDis         Flag to enable or disable the DISCOM. 1 Enable, 0 disable
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomEnable (const uint32_t     Unit,
                                r_wm_DiscomCfg_t * DiscomCfg, 
                                uint32_t           EnDis);
/***********************************************************/
/**
  @function  R_WM_DiscomIntEnable
  @brief     Enable the interrupt and create semaphore.
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
  @param[in]  EnDis         Flag to enable or disable the interrupt. 1 Enable, 0 disable
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomIntEnable (const uint32_t     Unit,
                                   r_wm_DiscomCfg_t * DiscomCfg,
                                   uint32_t           EnDis);

/***********************************************************/
/**
  @function  R_WM_DiscomInit
  @brief     Initialise the DISCOM.
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
    
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomInit(const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg);

/***********************************************************/
/**
  @function  R_WM_DiscomDeInit
  @brief     De - Initialise the DISCOM.
  
  @param[in]  Unit          Index of the Display Unit
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomDeInit(const uint32_t Unit);

/***********************************************************/
/**
  @function  R_WM_DiscomWait
  @brief     Wait for the interrupt signal of the DISCOM.
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
    
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomWait (const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg);

/***********************************************************/
/**
  @function  R_WM_ConfigDiscom
  @brief     Configure the DISCOM with the given parameters.
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
    
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ConfigDiscom(const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg); 

/***********************************************************/
/**
  @function  R_WM_DiscomSetCRC
  @brief     Set the DISCOM CRC Reference
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
  @param[in]  Crc           CRC value
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomSetCRC(const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg, const uint32_t Crc);

/***********************************************************/
/**
  @function  R_WM_DiscomGetCRC
  @brief     Get the CRC
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
  @param[out] Crc           Pointer to the CRC value
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomGetCRC(const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg, uint32_t * Crc);

/***********************************************************/
/**
  @function  R_WM_DiscomGetStatus
  @brief     Get the current DISCOM status
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
  @param[out] Status        Pointer to an integer giving the DISCOM status
  
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomGetStatus(const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg, uint32_t * Status);

/***********************************************************/
/**
  @function  R_WM_DiscomClear
  @brief     Clear the current DISCOM configuration.
  
  @param[in]  Unit          Index of the Display Unit
  @param[in]  DiscomCfg     DISCOM configuration parameter. See @ref r_wm_DiscomCfg_t
    
  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_DiscomClear (const uint32_t Unit, r_wm_DiscomCfg_t * DiscomCfg);

/**
  @}
*/

/***********************************************************/
/**
  @defgroup WMGeneral WM Generic functions
  @brief    WM functions of general usage.
  
  @{
*/

/***********************************************************/
/**
  @function  R_WM_ErrorCallbackSet
  @brief     Set the error callback function.

  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  ErrorCb   Error callback function

  @return see @ref r_wm_Error_t
*/
r_wm_Error_t R_WM_ErrorCallbackSet (const uint32_t Unit,
                                    void           (*ErrorCb) (uint32_t Unit,
                                                               r_wm_Error_t Error
                                                               )
                                    );

/***********************************************************/
/**
  @function  R_WM_ErrorHandler
  @brief     The function is the driver central error handler. 
  
  If the application has set an error handler call-back function, 
  the central error handler shall call it and then return to its caller. 
  The central error handler shall return in case no 
  error handler call-back function has been set.
  
  @param[in]  Unit      see @ref R_WM_DevInit
  @param[in]  Err       see @ref r_wm_Error_t

*/
void R_WM_ErrorHandler (const uint32_t     Unit,
                        const r_wm_Error_t Err
                        );

/**
  @}
*/
#ifdef __cplusplus
}
#endif


#endif /* WM_API_H__ */
