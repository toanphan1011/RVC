/******************************************************************************
 *
 * PURPOSE
 *   RIVP Reference Application for RIVP VIN Window Manger Wrapper
 *
 * AUTHOR
 *   Renesas Electronics Corporation
 *
 *
 ******************************************************************************/
/**
 * Copyright(C) 2017 Renesas Electronics Corporation. All Rights Reserved.
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation.
 * No part of this program may be reproduced or disclosed to
 * others, in any form, without the prior written permission
 * of Renesas Electronics Corporation.
 *
 ******************************************************************************/

/******************************************************************************/
/*                    INCLUDE FILES                                           */
/******************************************************************************/
#include <INTEGRITY.h>
#include "rivp_vin_api.h"
#include "rivp_app_vin_disp.h"
#include "rivp_app_vin_mmgr.h"
#include "rivp_dep_vin_log.h"

#include "rivp_app_vin_picout.h"
#include "rivp_app_vin_msg.h"
#include "rivp_app_vin_osal.h"
/* For MM */
#include "r_mmgr_config.h"
#include "r_mmgr_api.h"

/* For WM */
#include "r_ddb_api.h"
#include "r_wm_api.h"


/******************************************************************************/
/*                    MACROS/DEFINES                                          */
/******************************************************************************/
#define RIVP_APP_VIN_DISP_WIND_MAX		(4u)	/* max number of window */

/******************************************************************************/
/*                    TYPE DEFINITION                                         */
/******************************************************************************/
typedef struct {
	RIVP_BOOL					wndInit;		/* flag of window initialized */
	RIVP_BOOL					wndEnable;		/* flag of window is enable or disable */
	r_wm_Window_t				wndInfo;		/* window information */
} RIVP_APP_VIN_DISPCTL_T;

/******************************************************************************/
/*                    FORWARD DECLARATION                                     */
/******************************************************************************/
RIVP_STATIC RIVP_U32		s_rivpAppVinDispDevUint		= RIVP_APP_VIN_DISP_UNIT_HDMI0;
RIVP_STATIC RIVP_BOOL		s_rivpAppVinDispDevInit		= RIVP_FALSE;
RIVP_STATIC RIVP_BOOL		s_rivpAppVinDispScrInit		= RIVP_FALSE;
RIVP_STATIC RIVP_APP_VIN_DISPCTL_T	s_rivpAppVinDispCtl[RIVP_APP_VIN_DISP_WIND_MAX] = {RIVP_FALSE};
RIVP_STATIC r_wm_ClutEntry_t	s_rivpAppVinDispBgColor	= {0xaa, 0x00, 0x00, 0xff}; /* Bule */
RIVP_STATIC r_mmgr_MemBlock_t	s_rivpAppVinDispBuffChroma[RIVP_APP_VIN_DISP_WIND_MAX];
RIVP_STATIC r_mmgr_MemBlock_t	*s_rivpAppVinDispPtrBuffWM[RIVP_APP_VIN_DISP_WIND_MAX][RIVP_VIN_MAX_NUM_PICOUT_ADDR];

RIVP_STATIC RIVP_U32			s_rivpAppVinDiscomUint		= 0;
RIVP_STATIC RIVP_U32			s_rivpAppVinDocUint			= 0;
RIVP_STATIC r_wm_DiscomCfg_t	s_rivpAppVinDiscomConfig;

RIVP_U8 change=1;
RIVP_U8 flag_log=0;
//variable for picdisplay task
RIVP_STATIC RIVP_APP_VIN_PICOUT_INFO_T	s_rivpAppVinPicDisplayInfo; // to call terminate task_display
extern RIVP_APP_VIN_MSG_HND_T		s_rivpAppVinClientMsgHnd;


/******************************************************************************/
/*                         VARIABLE                                           */
/******************************************************************************/

/******************************************************************************/
/*                    EXTERNAL FUNCTIONS                                      */
/******************************************************************************/

/**
 * \brief		 initialize the DOC function
 *
 * \param[in]	 prm						 : Initialization doc parameter
 *
 * \retval		 RIVP_TRUE					 : Success
 * \retval		 RIVP_FALSE					 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDocInit(const RIVP_APP_VIN_DISP_PARAM_T *prm)
{
	RIVP_BOOL				lRet         = RIVP_FALSE;

#if (RIVP_VIN_SM_SUPPORT == 1)
	r_wm_Error_t			lWmRet;
	r_wm_DocParam_t			wmDocParam;
	r_wm_DocMonArea_t		wmDocMonArea;
	RIVP_U32				i;
	RIVP_U32				wmDocMonAreaBit;
	RIVP_U32				wmDocRefColorOffset;
	RIVP_U32				wmDocRefColorSize;
	RIVP_U32				referenceColor = 0;
	RIVP_U32				*wmDocRefColorTable;
	
	if (prm != RIVP_NULL) {

		lRet = RIVP_TRUE;

		s_rivpAppVinDocUint = prm->unit;

		wmDocParam.h_offset = 0;
		wmDocParam.v_offset = 0;
		wmDocParam.h_size = prm->height; // 1280x 800 , 640x400
		wmDocParam.v_size = prm->width;
		lWmRet = R_WM_ScreenDocParamSet(s_rivpAppVinDocUint, &wmDocParam);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDocInit] R_WM_ScreenDocParamSet(%d) res=[%d] \n", s_rivpAppVinDocUint, lWmRet);
		}

		wmDocMonArea.monarea_num = 0;
		wmDocMonArea.h_start = 0;
		wmDocMonArea.v_start = 0;
		wmDocMonArea.h_size = 200;//prm->height; 
		wmDocMonArea.v_size = 200;//prm->width;
		wmDocMonArea.ram_addr = RIVP_APP_VIN_DOC_RAM_ADDR;
		wmDocMonArea.threshold = RIVP_APP_VIN_DOC_THRESHOLD;

		for(i = 0; i < 4; i++){
			wmDocMonArea.ref_col[i].r_upper = RIVP_APP_VIN_DOC_R_UP_LIMIT;
			wmDocMonArea.ref_col[i].g_upper = RIVP_APP_VIN_DOC_G_UP_LIMIT;
			wmDocMonArea.ref_col[i].b_upper = RIVP_APP_VIN_DOC_B_UP_LIMIT;
			wmDocMonArea.ref_col[i].r_lower = RIVP_APP_VIN_DOC_R_LO_LIMIT;
			wmDocMonArea.ref_col[i].g_lower = RIVP_APP_VIN_DOC_G_LO_LIMIT;
			wmDocMonArea.ref_col[i].b_lower = RIVP_APP_VIN_DOC_B_LO_LIMIT;
		}

		lWmRet = R_WM_ScreenDocMonitorAreaSet(s_rivpAppVinDocUint, &wmDocMonArea);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDocInit] R_WM_ScreenDocMonitorAreaSet(%d) res=[%d] \n", s_rivpAppVinDocUint, lWmRet);
		}

		wmDocRefColorOffset 	= 0; //index of the first updated color
		wmDocRefColorSize 		= sizeof(referenceColor);
		wmDocRefColorTable 		= &referenceColor;

		lWmRet = R_WM_ScreenDocRefColorSet(s_rivpAppVinDocUint, wmDocRefColorOffset, wmDocRefColorSize, wmDocRefColorTable);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDocInit] R_WM_ScreenDocRefColorSet(%d, %d, %d, %p) res=[%d] \n", s_rivpAppVinDocUint, wmDocRefColorOffset, wmDocRefColorSize, wmDocRefColorTable, lWmRet);
		}

		lWmRet = R_WM_ScreenDocStatusClear(s_rivpAppVinDocUint);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDocInit] R_WM_ScreenDocStatusClear(%d) res=[%d] \n", s_rivpAppVinDocUint, lWmRet);
		}

		wmDocMonAreaBit	= RIVP_APP_VIN_DOC_MON_AREA_BIT;
		lWmRet = R_WM_ScreenDocCheckEnable(s_rivpAppVinDocUint, wmDocMonAreaBit);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDocInit] R_WM_ScreenDocCheckEnable(%d, %08X) res=[%d] \n", s_rivpAppVinDocUint, wmDocMonAreaBit, lWmRet);
		}
	}
#endif /* RIVP_VIN_SM_SUPPORT */

	return lRet;
}

/**
 * \brief		 Deinitialize the DOC function
 *
 * \retval		 RIVP_TRUE					 : Success
 * \retval		 RIVP_FALSE					 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDocDeinit(void)
{
	RIVP_BOOL				lRet			= RIVP_FALSE;

#if (RIVP_VIN_SM_SUPPORT == 1)
	RIVP_U32				wmDocMonAreaBit;
	r_wm_Error_t			lWmRet;
	
	lRet 			= RIVP_TRUE;
	wmDocMonAreaBit = RIVP_APP_VIN_DOC_MON_AREA_BIT;
	lWmRet = R_WM_ScreenDocCheckDisable(s_rivpAppVinDocUint, wmDocMonAreaBit);
	if(lWmRet != R_WM_ERR_OK) {
		lRet = RIVP_FALSE;
		RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDocDeinit] R_WM_ScreenDocCheckDisable(%d, %08X) res=[%d] \n", s_rivpAppVinDocUint, wmDocMonAreaBit, lWmRet);
	}
	s_rivpAppVinDocUint = 0;
#endif /* RIVP_VIN_SM_SUPPORT */	

	return lRet;
}


/**
 * \brief		 initialize the DISCOM function
 *
 * \param[in]	 prm						 : Initialization doc parameter
 *
 * \retval		 RIVP_TRUE					 : Success
 * \retval		 RIVP_FALSE					 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDiscomInit(const RIVP_APP_VIN_DISP_PARAM_T *prm)
{
	RIVP_BOOL				lRet				= RIVP_FALSE;

#if (RIVP_VIN_SM_SUPPORT == 1)
	RIVP_U32				wmEnDis				= 1;
	RIVP_U32				lDiscomCrc			= 0;
	RIVP_U32				lDiscomThreshold	= 1; //??????
	r_wm_Error_t			lWmRet;
	
	if (prm != RIVP_NULL) {

		lRet = RIVP_TRUE;

		s_rivpAppVinDiscomConfig.UifSelect 			= R_WM_DISCOM_SELECT_UIF4;
		s_rivpAppVinDiscomConfig.Target 			= R_WM_DISCOM_TGT_IN0;
		s_rivpAppVinDiscomConfig.Param.h_offset 	= 0;
		s_rivpAppVinDiscomConfig.Param.v_offset 	= 0;
		s_rivpAppVinDiscomConfig.Param.h_size 		= prm->height;
		s_rivpAppVinDiscomConfig.Param.v_size 		= prm->width;
		s_rivpAppVinDiscomConfig.Param.alpha_mode	= R_WM_DISCOM_ALPHA_PIXEL;
		s_rivpAppVinDiscomConfig.Param.threshold 	= lDiscomThreshold; /* limitation of number of matches */
		s_rivpAppVinDiscomUint 						= prm->unit;

		lWmRet = R_WM_ConfigDiscom(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDiscomInit] R_WM_ConfigDiscom( %d, 0x%08X ) res=[%d] \n", s_rivpAppVinDiscomUint , &s_rivpAppVinDiscomConfig, lWmRet);
		}

		lDiscomCrc = 0;
		lWmRet = R_WM_DiscomSetCRC(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, lDiscomCrc);
		if (lWmRet != R_WM_ERR_OK) {
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDiscomInit] R_WM_DiscomSetCRC(%u) res=[%d] \n", s_rivpAppVinDiscomUint, lWmRet);
		}

		// lWmRet = R_WM_DiscomClear(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig);
		// if(lWmRet != R_WM_ERR_OK) {
		// 	lRet = RIVP_FALSE;
		// 	RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDiscomInit] R_WM_DiscomClear( %d, 0x%08X ) res=[%d] \n", s_rivpAppVinDiscomUint , &s_rivpAppVinDiscomConfig, lWmRet);
		// }

		wmEnDis = 1;
		lWmRet = R_WM_DiscomEnable(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, wmEnDis);
		if(lWmRet != R_WM_ERR_OK) {
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDiscomInit] R_WM_DiscomEnable( %d, 0x%08X, %d ) res=[%d] \n", s_rivpAppVinDiscomUint , &s_rivpAppVinDiscomConfig, wmEnDis, lWmRet);
		}
	}
#endif /* RIVP_VIN_SM_SUPPORT */

	return lRet;
}

/**
 * \brief		 Deinitialize the DISCOM function
 *
 * \retval		 RIVP_TRUE					 : Success
 * \retval		 RIVP_FALSE					 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDiscomDeinit(void)
{
	RIVP_BOOL				lRet			= RIVP_FALSE;

#if (RIVP_VIN_SM_SUPPORT == 1)
	RIVP_U32				wmEnDis			= 0;
	r_wm_Error_t			lWmRet;
	
	lRet 	= RIVP_TRUE;
	wmEnDis = 0;
	lWmRet = R_WM_DiscomEnable(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, wmEnDis);
	if(lWmRet != R_WM_ERR_OK) {
		lRet = RIVP_FALSE;
		RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDiscomDeinit] R_WM_DiscomEnable( %d, 0x%08X, %d ) res=[%d] \n", s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, wmEnDis, lWmRet);
	}
	s_rivpAppVinDiscomUint = 0;
#endif /* RIVP_VIN_SM_SUPPORT */	

	return lRet;
}


/**
 * \brief		 initialize the WM Device
 *
 * \param[in]	 prm						 : Initialization disp parameter
 *
 * \retval		 RIVP_TRUE					 : Success
 * \retval		 RIVP_FALSE					 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDispInit(const RIVP_APP_VIN_DISP_PARAM_T *prm)
{
	RIVP_APP_VIN_DISPCTL_T	*lDispCtlPtr;
	RIVP_U32			lWindIdx;
	/* [RQT a300-1000] set initial value */
	RIVP_BOOL			lRet         = RIVP_FALSE;
	RIVP_BOOL			lChkParam    = RIVP_FALSE;
	r_wm_Error_t		lWmErr       = R_WM_ERR_OK;
	RIVP_U8				lBufNum      = 1u;
	r_wm_WinColorFmt_t	lFormat      = R_WM_COLORFMT_RGB0888;

	/* [RQT a300-1001] check arguments is not NULL */
	if (prm != RIVP_NULL) {
		/* [RQT a300-1002] check display unit state */
		if ((prm->unit >= RIVP_APP_VIN_DISP_UNIT_1) &&
			(prm->unit <= RIVP_APP_VIN_DISP_UNIT_3)) {
			/* [RQT a300-1003] set true to checking parameter */
			lChkParam = RIVP_TRUE;
			s_rivpAppVinDispDevUint = prm->unit;
		} else {
			/* [RQT a300-1004] set false to checking parameter */
			lChkParam = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispInit] Failed to check arguments, bat value prm->unit is %d. \n", prm->unit);
		}
	} else {
		/* [RQT a300-1005] set false to checking parameter */
		lChkParam = RIVP_FALSE;
		RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispInit] Failed to check arguments, prm is NULL. \n");
	}

	/* [RQT a300-1006] check checking parameter is true */
	if (lChkParam == RIVP_TRUE) {
		/* [RQT a300-1007] check format */
		switch (prm->format) {
		/* [RQT a300-1008] get color format and number of buffer */
		case RIVP_VIN_OUTF_YC422:
			lFormat = R_WM_COLORFMT_YCBCR422_UYVY;		/* as FB_FORMAT_UYVY */
			lBufNum = 1u;
			break;
		/* [RQT a300-1009] get color format and number of buffer */
		case RIVP_VIN_OUTF_YCSEP422:
			lFormat = R_WM_COLORFMT_YCBCR422_NV16_2PL;	/* as FB_FORMAT_YV16 */
			lBufNum = 2u;
			break;
		/* [RQT a300-1010] get color format and number of buffer */
		case RIVP_VIN_OUTF_YCSEP420:
			lFormat = R_WM_COLORFMT_YCBCR420_NV12_2PL;	/* as FB_FORMAT_NV12 */
			lBufNum = 2u;
			break;
		/* [RQT a300-1011] get color format and number of buffer */
		default: /* RIVP_VIN_OUTF_RGB0888 */
			lFormat = R_WM_COLORFMT_RGB0888;			/* as FB_FORMAT_RGB  */
			lBufNum = 1u;
			break;
		}

		/* [RQT a300-1012] check display device initialize state is false */
		if (s_rivpAppVinDispDevInit == RIVP_FALSE) {
			/* [RQT a300-1013] initialize WM/DU */
			lWmErr  = R_WM_DevInit(s_rivpAppVinDispDevUint);
			/* [RQT a300-1014] check WM error state is OK */
			if (lWmErr == R_WM_ERR_OK) {
				/* [RQT a300-1015] set event register by call WM function */
				lWmErr = R_WM_DevEventRegister(s_rivpAppVinDispDevUint, R_WM_EVENT_VBLANK, 0);
			}
		}
		/* [RQT a300-1016] check WM error state is OK */
		if (lWmErr == R_WM_ERR_OK) {
			/* [RQT a300-1017] set true to display device initialize state */
			s_rivpAppVinDispDevInit = RIVP_TRUE;

			/* [RQT a300-1018] check display screen initialize state is false */
			if (s_rivpAppVinDispScrInit == RIVP_FALSE) {

				/* [RQT a300-1019] set background color to WM error state */
				lWmErr = R_WM_ScreenBgColorSet(s_rivpAppVinDispDevUint,
												s_rivpAppVinDispBgColor.R,
												s_rivpAppVinDispBgColor.G,
												s_rivpAppVinDispBgColor.B);
			}

			/* [RQT a300-1020] check WM error state is OK */
			if (lWmErr == R_WM_ERR_OK) {

				/* [RQT a300-1021] check display screen initialize state is false */
				if (s_rivpAppVinDispScrInit == RIVP_FALSE) {

					/* [RQT a300-1022] be screen enabled */
					lWmErr = R_WM_ScreenEnable(s_rivpAppVinDispDevUint);
				}
				/* [RQT a300-1023] check WM error state is OK */
				if (lWmErr == R_WM_ERR_OK) {

					/* [RQT a300-1024] set true to display screen initialize state */
					s_rivpAppVinDispScrInit = RIVP_TRUE;

					/* [RQT a300-1035] create a windows */
					lWindIdx = prm->ch;

					lDispCtlPtr = &s_rivpAppVinDispCtl[lWindIdx];

					lDispCtlPtr->wndInfo.ColorFmt        = lFormat;
					lDispCtlPtr->wndInfo.Width           = prm->width;
					lDispCtlPtr->wndInfo.Height          = prm->height;
					lDispCtlPtr->wndInfo.PosZ            = lWindIdx;
					lDispCtlPtr->wndInfo.Pitch           = prm->width;
					lDispCtlPtr->wndInfo.Alpha           = 0xff; /* Opaque */
					lDispCtlPtr->wndInfo.Surface.BufNum  = lBufNum;
					lDispCtlPtr->wndInfo.Surface.Type    = R_WM_SURFACE_FB;
					lDispCtlPtr->wndInfo.Surface.BufMode = R_WM_WINBUF_ALLOC_EXTERNAL;

					/* [RQT a300-1025] check window index and set parameter */
					switch (lWindIdx) {
					case 1:
						lDispCtlPtr->wndInfo.PosX = (int32_t)prm->width;
						lDispCtlPtr->wndInfo.PosY = 0;
						break;
					case 2:
						lDispCtlPtr->wndInfo.PosX = 0;
						lDispCtlPtr->wndInfo.PosY = (int32_t)prm->height;
						break;
					case 3:
						lDispCtlPtr->wndInfo.PosX = (int32_t)prm->width;
						lDispCtlPtr->wndInfo.PosY = (int32_t)prm->height;
						break;
					default:
						lDispCtlPtr->wndInfo.PosX = 0;
						lDispCtlPtr->wndInfo.PosY = 0;
						break;
					}

					/* [RQT a300-1026] check window initialize state is false */
					if (lDispCtlPtr->wndInit == RIVP_FALSE) {
						/* [RQT a300-1027] create a window */
						lWmErr = R_WM_WindowCreate(s_rivpAppVinDispDevUint, &lDispCtlPtr->wndInfo);

						/* [RQT a300-1028] check WM error state is OK */
						if (lWmErr == R_WM_ERR_OK) {
							/* [RQT a300-1029] set true to window initialize state */
							lDispCtlPtr->wndInit = RIVP_TRUE;
						} else {
							RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispInit] Failed to #%u: R_WM_WindowCreate( %d, 0x%08X ) res=[%d] \n", (lWindIdx + 1u), s_rivpAppVinDispDevUint , &lDispCtlPtr->wndInfo, lWmErr);
						}
					}

					/* [RQT a300-1030] check WM error state is OK */
					if (lWmErr == R_WM_ERR_OK) {
						/* [RQT a300-1031] set result */
						lRet = RIVP_TRUE;
					}
				} else {
					RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispInit] Failed to R_WM_ScreenEnable( %d ) res=[%d] \n", s_rivpAppVinDispDevUint , lWmErr);
				}
			} else {
				RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispInit] Failed to R_WM_ScreenBgColorSet( %d ) res=[%d] \n", s_rivpAppVinDispDevUint , lWmErr);
			}
		} else {
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispInit] Failed to R_WM_DevInit( %d ) res=[%d] \n", s_rivpAppVinDispDevUint , lWmErr);
		}

		/* [RQT a300-1032] check result is false */
		if (lRet == RIVP_FALSE) {

			/* [RQT a300-1033] deinitialize WM device */
			RIVP_AppVinDispDeinit();
		}
	}

	/* [RQT a300-1034] return result */
	return lRet;
}

/**
 * \brief		 deinitialize the WM Device for the display output unit
 *
 * \retval		 RIVP_TRUE						 : Success
 * \retval		 RIVP_FALSE						 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDispDeinit(void)
{
	RIVP_U32					 lWindIdx;
	/* [RQT a301-1000] set initial value */
	RIVP_BOOL					 lRet        = RIVP_TRUE;
	r_wm_Error_t				 lWmErr      = R_WM_ERR_OK;
	RIVP_APP_VIN_DISPCTL_T		*lDispCtlPtr = RIVP_NULL;

	/* [RQT a301-1001] check window index */
	for (lWindIdx = 0u; lWindIdx < RIVP_APP_VIN_DISP_WIND_MAX; lWindIdx++) {

		lDispCtlPtr = &s_rivpAppVinDispCtl[lWindIdx];

		/* [RQT a301-1002] check window enable state is true */
		if (lDispCtlPtr->wndEnable == RIVP_TRUE) {

			/* [RQT a301-1003] disable window */
			r_wm_Error_t	err = R_WM_WindowDisable(s_rivpAppVinDispDevUint, &lDispCtlPtr->wndInfo);
			/* [RQT a301-1017] checks the result of R_WM_WindowDisable() */
			if (err == R_WM_ERR_OK) {
				/* [RQT a301-1004] set false to window enable */
				lDispCtlPtr->wndEnable = RIVP_FALSE;
			} else {
				RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispDeinit] Failed to #%u: R_WM_WindowDisable() error = %d\n", (lWindIdx + 1u), err);
			}
			lWmErr |= err;
		}

		/* [RQT a301-1005] check window initialize state is true */
		if (lDispCtlPtr->wndInit == RIVP_TRUE) {

			/* [RQT a301-1006] delete a window */
			r_wm_Error_t	err = R_WM_WindowDelete(s_rivpAppVinDispDevUint, &lDispCtlPtr->wndInfo);
			/* [RQT a301-1018] checks the result of R_WM_WindowDelete() */
			if (err == R_WM_ERR_OK) {
				/* [RQT a301-1007] set false to window initialize */
				lDispCtlPtr->wndInit = RIVP_FALSE;
			} else {
				RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispDeinit] Failed to #%u: R_WM_WindowDelete() error = %d\n", (lWindIdx + 1u), err);
			}
			lWmErr |= err;
		}
	}

	/* [RQT a301-1008] check display screen initialize state is true */
	if (s_rivpAppVinDispScrInit == RIVP_TRUE) {

		/* [RQT a301-1009] disable the screen */
		r_wm_Error_t	err = R_WM_ScreenDisable( s_rivpAppVinDispDevUint );
		/* [RQT a301-1019] checks the result of R_WM_ScreenDisable() */
		if (err == R_WM_ERR_OK) {
			/* [RQT a301-1010] set false to display screen initialize */
			s_rivpAppVinDispScrInit = RIVP_FALSE;
		} else {
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispDeinit] Failed to R_WM_ScreenDisable error = %d\n", err);
		}
		lWmErr |= err;
	}

	/* [RQT a301-1011] check display device initialize state is true */
	if (s_rivpAppVinDispDevInit == RIVP_TRUE) {

		/* [RQT a301-1012] deinitialize WM/DU */
		r_wm_Error_t	err = R_WM_DevDeinit(s_rivpAppVinDispDevUint);
		/* [RQT a301-1020] checks the result of R_WM_DevDeinit() */
		if (err == R_WM_ERR_OK) {
			/* [RQT a301-1013] set false to display device initialize */
			s_rivpAppVinDispDevInit = RIVP_FALSE;
		} else {
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispDeinit] Failed to R_WM_DevDeinit error = %d\n", err);
		}
		lWmErr |= err;
	}

	/* [RQT a301-1014] check WM error state is not OK */
	if (lWmErr != R_WM_ERR_OK) {
		/* [RQT a301-1015] set result */
		lRet= RIVP_FALSE;
	}

	/* [RQT a301-1016] return result */
	return lRet;

}

/**
 * \brief		 update framebuffers for display output.
 *
 * \param[in]	 ch								 : VIN channel
 * \param[in]	 buff							 : Update buffer parameter
 *
 * \retval		 RIVP_TRUE						 : Success
 * \retval		 RIVP_FALSE						 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDispUpdate(RIVP_U32 ch, const RIVP_VIN_OUTPUT_BUFF_T *buff)
{
	RIVP_APP_VIN_DISPCTL_T		*lDispCtlPtr;
	/* [RQT a302-1000] set initial value */
	RIVP_BOOL		lRet		= RIVP_TRUE;
	RIVP_U32		lWindIdx	= ch;
	r_wm_Error_t	lWmErr		= R_WM_ERR_OK;
	RIVP_PTR		lMemBlock	= RIVP_NULL;

	r_mmgr_MemBlock_t *pMemBlock	= RIVP_NULL;

	RIVP_BOOL		lOsalRet;

	/* [RQT a302-1001] check argument buff is not NULL */
	if (buff != RIVP_NULL) {
		/* [RQT a302-1002] check arguments ch */
		if (ch < RIVP_APP_VIN_DISP_WIND_MAX) {
			lDispCtlPtr = &s_rivpAppVinDispCtl[lWindIdx];
		} else {
			/* [RQT a302-1003] set result */
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispUpdate] Failed to check arguments, bat value ch is %d. \n", ch);
		}
	} else {
		/* [RQT a302-1004] set result */
		lRet = RIVP_FALSE;
		RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispUpdate] Failed to check arguments, prm is NULL. \n");
	}

	/* [RQT a302-1005] check result is true */
	if (lRet == RIVP_TRUE) {
		/* [RQT a302-1006] check window initialize state is not true */
		if (lDispCtlPtr->wndInit != RIVP_TRUE) {
			/* [RQT a302-1007] set result */
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispUpdate] Failed to check window initialize, bat value ch is %d. \n", ch);
		}
	}

	/* [RQT a302-1008] check result is true */
	if (lRet == RIVP_TRUE) {
		/* [RQT a302-1009] check window enable state is false */
		if (lDispCtlPtr->wndEnable == RIVP_FALSE) {

			/* [RQT a302-1010] be enable window */
			lWmErr = R_WM_WindowEnable( s_rivpAppVinDispDevUint, &lDispCtlPtr->wndInfo );
			/* [RQT a302-1023] checks the result of R_WM_WindowEnable() */
			if (lWmErr == R_WM_ERR_OK) {
				/* [RQT a302-1011] set true to window enable */
				lDispCtlPtr->wndEnable = RIVP_TRUE;
			} else {
				/* [RQT a302-1012] set result */
				lRet = RIVP_FALSE;
				RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispUpdate] Failed to #%u: R_WM_WindowEnable( %u, 0x%08X ) res=[%d] \n", (lWindIdx + 1u), s_rivpAppVinDispDevUint , &lDispCtlPtr->wndInfo, lWmErr);
			}
		}
	}

	/* [RQT a302-1013] check result is true */
	if (lRet == RIVP_TRUE) {

		/* [RQT a302-1014] get memory block */
		lOsalRet   = RIVP_AppVinGetMmgrMemBlock(buff->physAddr[RIVP_VIN_IDX_PICOUT_TOP_ADDR], &lMemBlock);
		/* [RQT a302-1024] checks the result of RIVP_AppVinGetMmgrMemBlock() */
		if ((lOsalRet != RIVP_TRUE) || (lMemBlock == RIVP_NULL)) {
			/* [RQT a302-1015] set result */
			lRet = RIVP_FALSE;
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispUpdate] Failed to RIVP_AppVinGetMmgrMemBlock( 0x%08X, 0x%08X ) res=[%d] \n", buff->physAddr[RIVP_VIN_IDX_PICOUT_TOP_ADDR], lMemBlock, lOsalRet);
		} else {
			/* [RQT a302-1016] set output image address of chroma for YCSEP420/422 format */
			s_rivpAppVinDispBuffChroma[ch].PhysAddr = buff->physAddr[RIVP_VIN_IDX_PICOUT_C_ADDR];
		}

	}

	/* [RQT a302-1019] check result is true */
	if (lRet == RIVP_TRUE) {
		pMemBlock=lMemBlock;
		memset((void *)pMemBlock->VmrStartAddr, 0xFF, (size_t)pMemBlock->Size);
		// if(change<=100){
		// 	memset((void *)pMemBlock->VmrStartAddr, 0xFF, (size_t)pMemBlock->Size);
		// 	change ++;
		// }
		// else if (change <=200) {
		// 	memset((void *)pMemBlock->VmrStartAddr, 0, (size_t)pMemBlock->Size);
		// 	change++;
		// }
		// else {
		// 	memset((void *)pMemBlock->VmrStartAddr, 0xFF, (size_t)pMemBlock->Size);
		// 	change= 1;
		// }

		s_rivpAppVinDispPtrBuffWM[ch][RIVP_VIN_IDX_PICOUT_TOP_ADDR] = (r_mmgr_MemBlock_t *)lMemBlock;
		s_rivpAppVinDispPtrBuffWM[ch][RIVP_VIN_IDX_PICOUT_C_ADDR] = &s_rivpAppVinDispBuffChroma[ch];

		/* [RQT a302-1020] set the framebuffer address */
		lWmErr = R_WM_WindowExternalBufSet(s_rivpAppVinDispDevUint, &lDispCtlPtr->wndInfo, s_rivpAppVinDispPtrBuffWM[ch], lDispCtlPtr->wndInfo.Surface.BufNum, lDispCtlPtr->wndInfo.ColorFmt);
		/* [RQT a302-1025] checks the result of R_WM_WindowExternalBufSet() */
		if (lWmErr == R_WM_ERR_OK) {
			/* [RQT a302-1021] set result */
			lRet = RIVP_TRUE;
		} else {
			 RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispUpdate] Failed to R_WM_WindowExternalBufSet(%u, 0x%08X, 0x%08X, 1, %d) res=[%d] \n",
									s_rivpAppVinDispDevUint, &lDispCtlPtr->wndInfo, s_rivpAppVinDispPtrBuffWM[ch], lDispCtlPtr->wndInfo.Surface.BufNum, lDispCtlPtr->wndInfo.ColorFmt, lWmErr );
		}
	}

	/* [RQT a302-1022] return result */
	return lRet;
}

/**
 * \brief		 wait for display ouput.
 *
 * \retval		 RIVP_TRUE						 : Success
 * \retval		 RIVP_FALSE						 : Failure
 *
 */
RIVP_BOOL RIVP_AppVinDispWaitOutput(void)
{
	/* [RQT a303-1000] set initial value */
	RIVP_BOOL		lRet			= RIVP_FALSE;
	r_wm_Error_t	lWmErr			= R_WM_ERR_OK;
	RIVP_U32		lDocStatus      = 0;
	RIVP_U32		lDiscomStatus	= 0;
	RIVP_U32		lDiscomCrc		= 0;

	/* [RQT a303-1001] check display device initialize state is true */
	if (s_rivpAppVinDispDevInit == RIVP_TRUE) {
		/* [RQT a303-1002] wait for the given event to occur and set WM error */
		lWmErr = R_WM_DevWaitForEvent(s_rivpAppVinDispDevUint, R_WM_EVENT_VBLANK);

		/* [RQT a303-1003] check WM error state is not OK */
		if (lWmErr != R_WM_ERR_OK) {
			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispWaitOutput] Failed to R_WM_DevWaitForEvent(%u, R_WM_EVENT_VBLANK) res=[%d] \n",
									s_rivpAppVinDispDevUint, lWmErr);
		} else {
			/* [RQT a303-1004] set result */
			lRet = RIVP_TRUE;

			// check DOC
			if (s_rivpAppVinDocUint != 0){
				lWmErr = R_WM_ScreenDocStatusGet(s_rivpAppVinDocUint, &lDocStatus);
				if (lWmErr != R_WM_ERR_OK) {
					RIVP_VIN_LOG_APP_ERR_SYS("[RIVP_AppVinDispWaitOutput] Failed to R_WM_ScreenDocStatusGet(%u) res=[%d] \n", s_rivpAppVinDocUint, lWmErr);
				} else {
					// if (lDocStatus != 0) {
						/* Video Output Monitor area error */
						// RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispWaitOutput] DOC Error lDocStatus=[%d] \n", lDocStatus);
						// if (flag_log !=lDocStatus){
							// RIVP_VIN_LOG_APP_WNG("%d\n", lDocStatus);
							printf("%d \n",lDocStatus);
							// flag_log = lDocStatus;
						//}
					// }
				}
			}
			
			//check DISCOM
			// if (s_rivpAppVinDiscomUint != 0){
			// 	lWmErr = R_WM_DiscomGetStatus(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, &lDiscomStatus);
			// 	if (lWmErr != R_WM_ERR_OK) {
			// 		RIVP_VIN_LOG_APP_ERR_SYS("[RIVP_AppVinDispWaitOutput] Failed to R_WM_DiscomGetStatus(%u) res=[%d] \n", s_rivpAppVinDiscomUint, lWmErr);
			// 	} else {
			// 		if (lDiscomStatus == 0) {
			// 			/* If the CRC code doesn’t match with the expectation value, DOCMSTR.CMPST bit is set to 1. */
			// 			/* If current CRC is matched with expected CRC (previous CRC) -> Frozen Image Detection */
			// 			RIVP_VIN_LOG_APP_WNG("[RIVP_AppVinDispWaitOutput] FROZEN_IMAGE_DETECTION lDiscomStatus=[%d] \n", lDiscomStatus);
			// 		}

			// 		/* Get current image CRC */
			// 		lWmErr = R_WM_DiscomGetCRC(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, &lDiscomCrc);
			// 		if (lWmErr != R_WM_ERR_OK) {
			// 			RIVP_VIN_LOG_APP_ERR_SYS("[RIVP_AppVinDispWaitOutput] R_WM_DiscomGetCRC(%u) res=[%d] \n", s_rivpAppVinDiscomUint, lWmErr);
			// 		} else {
			// 			/* Set expected CRC by current image CRC */
			// 			lWmErr = R_WM_DiscomSetCRC(s_rivpAppVinDiscomUint, &s_rivpAppVinDiscomConfig, lDiscomCrc);
			// 			if (lWmErr != R_WM_ERR_OK) {
			// 				RIVP_VIN_LOG_APP_ERR_SYS("[RIVP_AppVinDispWaitOutput] R_WM_DiscomSetCRC(%u) res=[%d] \n", s_rivpAppVinDiscomUint, lWmErr);
			// 			}
			// 		}
			// 	}
			// }
		}
	}
	/* [RQT a303-1005] return result */
	return lRet;
}

/******************************************************************************/
/*                    INTERNAL FUNCTIONS                                      */
/******************************************************************************/

/**
 * \brief		 Display Picture
 *
 * \param[in]	 picParam			: picture parameter
 *
 * \retval		 none				: none
 */
void RIVP_AppVinPicDisplayTask (RIVP_PTR arg)
{
	// FILE *fp;

	// fp=fopen ("file.txt","w");

	// int flag_w=0;

	RIVP_APP_VIN_PICOUT_INFO_T	lDisplayInfo;
	RIVP_APP_VIN_CMN_INFO_T *lAppInfo;
	RIVP_VIN_PICPARAM_T		*lPicParam;
	RIVP_BOOL				 lLoopFlg;
	RIVP_BOOL				 lRetSem;
	RIVP_BOOL				 lRet;
	RIVP_PTR				 lSem;
	RIVP_APP_VIN_MSG_HND_T	 lMsgHnd;
	RIVP_U32				 lLoopCnt;

	RIVP_VIN_LOG_APP_INF("RIVP_AppVinPicDisplayTask Start\n");

	/* [RQT ae02-1000] set initial value */
	// lResult 	= RIVP_RTN_FATAL_SYSTEM;
	lSem		= arg;
	lLoopCnt	= 0u;
	memset(&lMsgHnd, 0, sizeof(RIVP_APP_VIN_MSG_HND_T));

	/* [RQT ae02-1001] check arguments is not NULL */
	if (lSem != RIVP_NULL) {
		/* [RQT ae02-1002] lock output task semaphore by call UDF function and set loop flag */
		lRetSem = RIVP_AppVinOsalSemLock(lSem);
		lLoopFlg = lRetSem;

		/* [RQT ae02-1003] check loop flag is not true */
		if (lLoopFlg != RIVP_TRUE) {
			RIVP_VIN_LOG_APP_ERR_SYS("RIVP_AppVinOsalSemLock failed!!\n");
		} else {
			/* [RQT ae02-1004] open message server connection by call internal function and set loop flag */
			lLoopFlg = RIVP_AppVinMsgOpen(RIVP_APP_VIN_MSG_ID_PICOUT_S, &lMsgHnd);
			if (lLoopFlg != RIVP_TRUE) {
				RIVP_VIN_LOG_APP_ERR_SYS("RIVP_AppVinMsgGetHnd failed!!\n");
			}
		}

		/* [RQT ae02-1005] check loop flag */
		while (lLoopFlg) {
			/* [RQT ae02-1006] wait for receive message */
			lRet = RIVP_AppVinMsgReceive(&lMsgHnd, (RIVP_U32)sizeof(RIVP_APP_VIN_PICOUT_INFO_T), &lDisplayInfo);
			/* [RQT ae02-1007] check result of RIVP_AppVinMsgReceive() is not true */
			if (lRet != RIVP_TRUE) {
				RIVP_VIN_LOG_APP_ERR_SYS("RIVP_AppVinMsgReceive Failed!! loop count=%u\n", lLoopCnt);
			} else {
				/* [RQT ae02-1008] check task stop flag is true */
				if (lDisplayInfo.stopTask == RIVP_TRUE) {
					/* [RQT ae02-1009] set FALSE to ends this loop */
					lLoopFlg = RIVP_FALSE;
				} else {
					lAppInfo	= lDisplayInfo.appInfo;
					// lContext	= lDisplayInfo.context;
					lPicParam	= &lDisplayInfo.picParam;

					/* [RQT ae02-1010] check display update is true */
					if (lDisplayInfo.exe == RIVP_TRUE) {
						/* [RQT ae02-1011] check pairing for SM */


						/* [RQT ae02-1012] get current time for begin time of update display process by call internal function */
						RIVP_AppVinTimeGet(&lAppInfo->perforanceInfo.du);

						/* [RQT ae02-1013] update display by call internal function */

					//	RIVP_AppVinPicOutUpdate(lPicParam);
						lRet = RIVP_AppVinDispUpdate(lPicParam->ch, &lPicParam->buff);
						
						////////////////////////////Wait for display output/////////

						//RIVP_BOOL	lRet;
						/* [RQT ae09-1000] wait for display ouput by call internal function */
						lRet = RIVP_AppVinDispWaitOutput();

						if (lRet == RIVP_FALSE) {
						RIVP_VIN_LOG_APP_ERR_SYS("RIVP_AppVinDispWaitOutput returns FALSE.\n");
						}

						RIVP_AppVinTimeGetProc(&lAppInfo->perforanceInfo, RIVP_APP_VIN_CMN_FUNC_DU);
					}
				}
			}
			lLoopCnt++;
		}
		/* [RQT ae02-1020] close message server connection by call internal function */
		RIVP_AppVinMsgClose(&lMsgHnd);

		/* [RQT ae02-1021] check semaphore is true */
		if (lRetSem == RIVP_TRUE) {
			/* [RQT ae02-1022] unlock output task semaphore by call UDF function */
			RIVP_AppVinOsalSemUnlock(lSem);
		}
	}
	RIVP_VIN_LOG_APP_INF("RIVP_AppVinPicDisplayTask return\n");
}


///////////////////////////////////////////////////////
/**
 * \brief		 terminate display callback task
 *
 * \retval		 none				: none
 */
void RIVP_AppVinPicDisplayTerminateTask(void)
{
	/* [RQT ae05-1000] open message client connection by call internal function */
	s_rivpAppVinPicDisplayInfo.stopTask = RIVP_TRUE;
	(void)RIVP_AppVinMsgSend(&s_rivpAppVinClientMsgHnd, (RIVP_U32)sizeof(RIVP_APP_VIN_PICOUT_INFO_T), &s_rivpAppVinPicDisplayInfo);
}

