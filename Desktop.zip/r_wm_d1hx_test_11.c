/*
****************************************************************************
PROJECT : RCAR-M3 WM Evaluation
FILE    : $Id: r_wm_d1hx_test_02.c 10755 2016-10-27 15:29:40Z michael.golczewski $
============================================================================ 
DESCRIPTION
Main functions of the D1H test suite
============================================================================
                            C O P Y R I G H T                            
============================================================================
                           Copyright (c) 2015
                                  by 
                       Renesas Electronics (Europe) GmbH. 
                           Arcadiastrasse 10
                          D-40472 Duesseldorf
                               Germany
                          All rights reserved.
============================================================================
Purpose: only for testing

DISCLAIMER                                                                   
This software is supplied by Renesas Electronics Corporation and is only     
intended for use with Renesas products. No other uses are authorized. This   
software is owned by Renesas Electronics Corporation and is protected under  
all applicable laws, including copyright laws.                               
THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING  
THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT      
LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE   
AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.          
TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS       
ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE  
FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR   
ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE  
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.                             
Renesas reserves the right, without notice, to make changes to this software 
and to discontinue the availability of this software. By using this software,
you agree to the additional terms and conditions found by accessing the      
following link:                                                              
http://www.renesas.com/disclaimer *                                          
Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.     

****************************************************************************
*/

/*******************************************************************************
  Title: tests 11:  Test the WM Display DOC configuration

  Implementation of the application tests for R-Car H3/M3 WM.
*/

/*******************************************************************************
  Section: Includes
*/

#pragma ghs startnomisra
#include <INTEGRITY.h>
#include <util/error_string.h>
#include <bsp.h>
#pragma ghs endnomisra
#include "common.h"

#include "r_mmgr_config.h"
#include "r_mmgr_api.h"
#include "r_config_wm.h"
#include "r_config_vspd.h"
#include "r_ddb_api.h"
#include "r_wm_api.h"
#include "r_wm_d1hx_test_common.h"
//#include "001_VGA_YUV420.h"

/*******************************************************************************
  Section: Defines
*/

/*******************************************************************************
  Define: LOC_DISPLAY
  
  Default display unit used in this test
*/
#define LOC_DISPLAY       R_WM_DEV_DU1



/*******************************************************************************
  Variable: locWindow
  
  Array where the window information are stored.
  
*/
static r_wm_Window_t *locWindows;


static uint32_t DocErrCnt[R_WM_DOC_NUM][2]={0};
static Task     children[R_WM_DOC_NUM][2];

/*******************************************************************************
    Section: Local Functions prototypes
*/
    
    
    
/*******************************************************************************
    Section: Local Functions
*/


static void loc_ErrTask0_chk(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(0, R_WM_DOC_INTC_VOC))
        { 
            DocErrCnt[0][0]++; 
       }
    }
    Exit(0);
}
static void loc_ErrTask0_mon(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(0, R_WM_DOC_INTC_ACTMON))
        { 
            DocErrCnt[0][1]++; 
        }
    }
    Exit(0);
}

static void loc_ErrTask1_chk(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(1, R_WM_DOC_INTC_VOC))
        { 
            DocErrCnt[1][0]++; 
       }
    }
    Exit(0);
}
static void loc_ErrTask1_mon(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(1, R_WM_DOC_INTC_ACTMON))
        { 
            DocErrCnt[1][1]++; 
        }
    }
    Exit(0);
}
static void loc_ErrTask2_chk(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(2, R_WM_DOC_INTC_VOC))
        { 
            DocErrCnt[2][0]++; 
       }
    }
    Exit(0);
}
static void loc_ErrTask2_mon(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(2, R_WM_DOC_INTC_ACTMON))
        { 
            DocErrCnt[2][1]++; 
        }
    }
    Exit(0);
}

#ifdef RCAR_H3
static void loc_ErrTask3_chk(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(3, R_WM_DOC_INTC_VOC))
        { 
            DocErrCnt[3][0]++; 
       }
    }
    Exit(0);
}
static void loc_ErrTask3_mon(void)
{
    static uint32_t run = 1; 
       
    while(run)
    {
        if (R_WM_ERR_OK == R_WM_ScreenDocIntWait(3, R_WM_DOC_INTC_ACTMON))
        { 
            DocErrCnt[3][1]++; 
        }
    }
    Exit(0);
}
#endif


uint32_t EXPD[16384]={0u};

#define MON_CNT    (1u)
#define MON_SIZE  (200u)
#define MON_AREA   (0u)
#define MON_AREA_MASK   ((uint32_t)0x00000001u<<MON_AREA)
char_t *doc_execute(uint32_t Unit, uint32_t Width, uint32_t Height, uint32_t isSuccess, uint32_t isInterrupt)
{
    uint32_t ret            =0u;
    uint32_t errors         =0u;
    uint32_t remain         =0u;
    uint32_t ent            =0u;
    uint32_t i=0u, j=0u, k  =0u;
    uint32_t test_time      =10u;
    r_wm_DocParam_t Param   ={0};
    r_wm_DocMonArea_t MonAreaParam  ={0};
    uint32_t status                 =0;
    char *mode_name[2]              ={"Polling", "Interrupt"};
    uint32_t res_ent;
    char *result_name[2]            ={"Success", "Error"};
    r_wm_Error_t wm_err             = R_WM_ERR_OK;
    memset(EXPD, 0, sizeof(EXPD));

    //DOC
    Param.h_offset = 0x0020;
    Param.v_offset = 0x0008;
    Param.h_size   = Width;
    Param.v_size   = Height;
    wm_err = R_WM_ScreenDocParamSet(Unit, &Param);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to set parameters, WM Error = %d\n", wm_err);
        ret++;
    }

    //Monitor Area
    MonAreaParam.monarea_num = MON_AREA;
//DOC0MmCFG0
    MonAreaParam.h_start = 0;
    MonAreaParam.v_start = 0;
//DOC0MmCFG1
    MonAreaParam.h_size = MON_SIZE;
    MonAreaParam.v_size = MON_SIZE;
//DOC0MmCFG2
    MonAreaParam.ram_addr = 0;
//DOC0MmCFG3
    MonAreaParam.threshold = 1;
//DOC0MmCFG4-7
    if(isSuccess == (uint32_t)false)
    {
        MonAreaParam.ref_col[0].r_upper = 0x9;
    }
    else
    {
        MonAreaParam.ref_col[0].r_upper = 0xB;
    }
    MonAreaParam.ref_col[0].g_upper = 0xF;
    MonAreaParam.ref_col[0].b_upper = 0xF;
    MonAreaParam.ref_col[0].r_lower = 0;
    MonAreaParam.ref_col[0].g_lower = 0;
    MonAreaParam.ref_col[0].b_lower = 0;
    memcpy(&MonAreaParam.ref_col[1], &MonAreaParam.ref_col[0], sizeof(MonAreaParam.ref_col[0]));
    memcpy(&MonAreaParam.ref_col[2], &MonAreaParam.ref_col[0], sizeof(MonAreaParam.ref_col[0]));
    memcpy(&MonAreaParam.ref_col[3], &MonAreaParam.ref_col[0], sizeof(MonAreaParam.ref_col[0]));
    
    wm_err = R_WM_ScreenDocMonitorAreaSet(Unit, &MonAreaParam);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to set parameters, WM Error = %d\n", wm_err);
        ret++;
    }

    //Color RAM
    ent=0u;
    for(k=0u;k<MON_CNT;k++)
    {
        for(j=0u;j<(MON_SIZE/2u);j++)
        {
            for(i=0u;i<(MON_SIZE/8u);i++)
            {
                EXPD[ent] = 0x00000000u;
                ent+=1u;
            }
            for(i=0u;i<(MON_SIZE/8u);i++)
            {
                EXPD[ent] = 0x00005555u;
                ent+=1u;
            }
        }
        for(j=0u;j<(MON_SIZE/2u);j++)
        {
            for(i=0u;i<(MON_SIZE/8u);i++)
            {
                EXPD[ent] = 0x0000AAAAu;
                ent+=1u;
            }
            for(i=0u;i<(MON_SIZE/8u);i++)
            {
                EXPD[ent] = 0x0000FFFFu;
                ent+=1u;
            }
        }
    }
    
    wm_err = R_WM_ScreenDocRefColorSet(Unit, 0, ent, EXPD);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to set ref colors, WM Error = %d\n", wm_err);
        ret++;
    }
 

    // Main part - Start DOC and check the display frame in specified seconds.
    wm_err = R_WM_ScreenDocStatusClear(Unit);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to clear status, WM Error = %d\n", wm_err);
        ret++;
    }
    wm_err = R_WM_ScreenDocCheckEnable(Unit, MON_AREA_MASK);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to enable DOC check, WM Error = %d\n", wm_err);
        ret++;
    }
 
    if(isInterrupt == 1u)
    {
        DocErrCnt[Unit][0]=0;
        wm_err = R_WM_ScreenDocIntcEnable(Unit, R_WM_DOC_INTC_VOC);
        if (R_WM_ERR_OK != wm_err)
        {
            printf("[doc_execute] Failed to enable interrupt, WM Error = %d\n", wm_err);
            ret++;
        }
    }

    for (remain = test_time; remain > 0u; remain--) 
    {
        //wait for FrameEnd interrupt
        R_WM_DevWaitForEvent(Unit, R_WM_EVENT_VBLANK);

        if(isInterrupt == 0u)
        {
            wm_err = R_WM_ScreenDocStatusGet(Unit, &status);
            if (R_WM_ERR_OK != wm_err)
            {
                printf("[doc_execute] Failed to get status, WM Error = %d\n", wm_err);
                ret++;
            }
    
            if ((status & 0x00800000u) != 0u) 
            {
            //                printf("DOC: Detected parameter error, 0x%08x.\n", status);
            }
            if ((status & 0x00030000u) != 0u) 
            {
            //                printf("DOC: Detected active monitor error, 0x%08x.\n", status);
            }
            if ((status & 0x0000FFFFu) != 0u) 
            {
            //                printf("DOC: Detected output monitor error, 0x%08x.\n", status);
            }
            if ((status & 0x0083FFFFu) != 0u) 
            {
                errors++;
                break;
            }
            else
            {
            //                printf("DOC: Compare success\n");
            }
        }
        else
        {
            if(DocErrCnt[Unit][0]>0)
            {
                errors++;
                break;
            }
        }
    }

    if(isInterrupt == 1u)
    {
        wm_err = R_WM_ScreenDocIntcEnable(Unit, R_WM_DOC_INTC_DISABLE);
        if (R_WM_ERR_OK != wm_err)
        {
            printf("[doc_execute] Failed to disable interrupt, WM Error = %d\n", wm_err);
            ret++;
        }
    }
    wm_err = R_WM_ScreenDocCheckDisable(Unit, MON_AREA_MASK);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to disable check, WM Error = %d\n", wm_err);
        ret++;
    }

    wm_err = R_WM_ScreenDocStatusClear(Unit);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to clear status, WM Error = %d\n", wm_err);
        ret++;
    }

    if(((isSuccess == (uint32_t)true) && (errors == 0)) || ((isSuccess == (uint32_t)false) && (errors > 0)))
    {
        res_ent=0;
    }
    else
    {
        res_ent=1;
    }

    if(errors > 0)
    {
        printf("DOC: Test %s output monitor mismatch detect.(%s mode)\n", result_name[res_ent], mode_name[isInterrupt]);
    }
    else
    {
        printf("DOC: Test %s output monitor no mismatch.(%s mode)\n", result_name[res_ent], mode_name[isInterrupt]);
    }
    if ((0 != ret) || (0 != res_ent))
    {
         return (char_t*)"Err";
    }
    else
    {
        return NULL;
    }
}

#define ACT_MON_MASK   (0x00010000u)
char_t *doc_execute_active(uint32_t Unit, uint32_t Width, uint32_t Height, uint32_t isSuccess, uint32_t isInterrupt)
{
    uint32_t errors=0u;
    uint32_t ret=0u;
    uint32_t remain=0u;
    uint32_t i=0u;
//    uint32_t test_time=100u;
    uint32_t test_time=10u;
    uint32_t TIMEs[4]={0x0FFF0000u, 0x0FFF0100u, 0x0FFF0200u, 0x0FFF0300u};
//    uint32_t TIMEs[4]={0x0FFF0000u, 0x0FFF0100u, 0x0FFF0200u, 0x00000000u};
    r_wm_DocParam_t Param={0};
    uint16_t UpperTime;
    uint16_t LowerTime;
    uint32_t status=0;
    char *mode_name[2]={"Polling", "Interrupt"};
    uint32_t res_ent;
    char *result_name[2]={"Success", "Error"};
    r_wm_Error_t wm_err     = R_WM_ERR_OK;

    //DOC
    Param.h_offset = 0x0020;
    Param.v_offset = 0x0008;
    Param.h_size   = Width;
    Param.v_size   = Height;
    wm_err = R_WM_ScreenDocParamSet(Unit, &Param);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute_active] Failed to set parameters, WM Error = %d\n", wm_err);
        ret++;
    }

//    for(i=0u; i<4u; i++){

    if(isSuccess == (uint32_t)true)
    {
        i = 0;
    }
    else
    {
        i = 3;
    }

    // Main part - Start DOC and check the display frame in specified seconds.
    errors=0u;
    wm_err = R_WM_ScreenDocStatusClear(Unit);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute_active] Failed to clear status, WM Error = %d\n", wm_err);
        ret++;
    }

    UpperTime = TIMEs[i]>>16;
    LowerTime = TIMEs[i]&0xffff;
    wm_err = R_WM_ScreenDocMonEnable(Unit, UpperTime, LowerTime);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute_active] Failed to enable monitor, WM Error = %d\n", wm_err);
        ret++;
    }


    if(isInterrupt == (uint32_t)true)
    {
        DocErrCnt[Unit][1]=0;
        wm_err = R_WM_ScreenDocIntcEnable(Unit, R_WM_DOC_INTC_ACTMON);
        if (R_WM_ERR_OK != wm_err)
        {
            printf("[doc_execute_active] Failed to enable interrupt, WM Error = %d\n", wm_err);
            ret++;
        }
    }

    for (remain = test_time; remain > 0u; remain--) 
    {
    // Check DOC status in every VSYNC.
    //wait for FrameEnd interrupt
        R_WM_DevWaitForEvent(Unit, R_WM_EVENT_VBLANK);
    
    
        if(isInterrupt == (uint32_t)false)
        {
    
            wm_err = R_WM_ScreenDocStatusGet(Unit, &status);
            if (R_WM_ERR_OK != wm_err)
            {
                printf("[doc_execute_active] Failed to get status, WM Error = %d\n", wm_err);
                ret++;
            }
    
            if ((status & 0x00800000u) != 0u) 
            {
    //          printf("DOC: Detected parameter error, 0x%08x.\n", status);
            }
            if ((status & 0x00030000u) != 0u) 
            {
    //      printf("DOC: Detected active monitor error, 0x%08x.\n", status);
            }
            if ((status & 0x00830000u) != 0u) 
            {
                errors++;
                break;
            }
        }
        else
        {
            if(DocErrCnt[Unit][1] > 0)
            {
                errors++;
                break;
            }
        }
    }

    if(isInterrupt == (uint32_t)true)
    {
        wm_err = R_WM_ScreenDocIntcEnable(Unit, R_WM_DOC_INTC_DISABLE);
        if (R_WM_ERR_OK != wm_err)
        {
            printf("[doc_execute] Failed to disable interrupt, WM Error = %d\n", wm_err);
            ret++;
        }
    }
    wm_err = R_WM_ScreenDocMonDisable(Unit);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to disable check, WM Error = %d\n", wm_err);
        ret++;
    }


    wm_err = R_WM_ScreenDocStatusClear(Unit);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute_active] Failed to clear status, WM Error = %d\n", wm_err);
        ret++;
    }


    if(((isSuccess == (uint32_t)true) && (errors == 0)) || ((isSuccess == (uint32_t)false) && (errors > 0)))
    {
        res_ent=0;
    }
    else
    {
        res_ent=1;
    }

    if(errors > 0)
    {
        printf("DOC: Test %s active monitor[detect time 0x%08x] mismatch detect.(%s mode)\n", result_name[res_ent], TIMEs[i], mode_name[isInterrupt]);
    }
    else
    {
        printf("DOC: Test %s active monitor[detect time 0x%08x] no mismatch.(%s mode)\n", result_name[res_ent], TIMEs[i], mode_name[isInterrupt]);
    }
//    }
    if ((0 != ret) || (0 != res_ent))
    {
         return (char_t*)"Err";
    }
    else
    {
        return NULL;
    }
}

/*******************************************************************************
  Function: loc_prepareLayerGeom
  
  This function calculate the layer size and position on screen
  
*/
static void loc_prepareLayerGeom (const r_wm_SurfaceType_t     Type,
                                  const r_wm_WinBufAllocMode_t BufMode,
                                  const r_wm_WinColorFmt_t     ColorFmt,
                                  const uint32_t               BufNum,
                                  const uint32_t               layerNum,
                                  const uint32_t               screenWidth,
                                  const uint32_t               screenHeight,
                                  r_wm_Window_t              * Win
                                  )
{
    uint32_t i;

    for (i = 0; layerNum > i; i++)
    {
        memset(&Win[i], 0, sizeof(r_wm_Window_t));
        Win[i].ColorFmt  = ColorFmt;
        Win[i].PosX      = i * (screenWidth  / (2*layerNum));
        Win[i].PosY      = i * (screenHeight / (2*layerNum));
        Win[i].PosZ      = i; 
        Win[i].Pitch     = screenWidth  ;
        Win[i].Width     = screenWidth  ;
        Win[i].Height    = screenHeight ;
        Win[i].Alpha     = 0xff; /* Opaque*/
        
        Win[i].Surface.BufNum  = BufNum;
        Win[i].Surface.Type    = Type;
        Win[i].Surface.BufMode = BufMode;
    }
}


/*******************************************************************************
  Function: loc_RenderToFb
  
  This function write to the off screen framebuffer and call the swap function when ready
  
*/
static r_wm_Error_t loc_RenderToFb (uint32_t Unit, r_wm_Window_t * Win,
                                    const uint32_t  colour
                                    )
{
    r_wm_Error_t        err;
    r_mmgr_MemBlock_t * rect = NULL;
    
    do
    {
        err = R_WM_DevWaitForEvent(Unit, R_WM_EVENT_VBLANK);
        if (R_WM_ERR_OK != err)
        {
            printf("[loc_RenderToFb] Wait for Video sync err = %d\n", err);
            return err;
        }
        /* Not used: just to change the status of the buffers (that are written by the Texture side) */
        rect = (r_mmgr_MemBlock_t *)R_WM_WindowNewDrawBufGet(Unit, Win);
    } while (NULL == rect);
    
    R_WM_Test_FillColorRGB(rect, colour, Win);

    return err;
}

//#define DOC_TEST_DRVS (1u)
#define DOC_TEST_DRVS (R_WM_DOC_NUM)
#define DOC_TEST_LAYERS (1u)
#define DOC_TEST_LAYER_NUM (DOC_TEST_DRVS*DOC_TEST_LAYERS)

static uint32_t MyColours[DOC_TEST_LAYERS] = {
0xFFB04040u  //dark red, 
/*    0xF0FF8000u, //orange 
    0xF4FFFF00u, //yellow, 
    0xF800FF00u, //green, 
    0x800000FFu //blue 
    //0xFFFFFFFFu
*/
};     


//char_t* test_discom_du(uint32_t duch, r_vsp_Discom_Select_t Select)
static uint32_t loc_Test_Doc(uint32_t DuUnit, uint32_t LayerNumMax, uint32_t WidthMax, uint32_t HeightMax)
{
    char *ptr;
    uint32_t ret = 0; 
    uint32_t Width;
    uint32_t Height;
    uint32_t layerIndex;
    r_wm_Error_t        wm_err;
    
    Width = WidthMax/2;
    Height = HeightMax/2;
    /* Allocate the windows locally */
    locWindows = (r_wm_Window_t *)malloc(sizeof(r_wm_Window_t) * LayerNumMax);
    loc_prepareLayerGeom(R_WM_SURFACE_FB,
                         R_WM_WINBUF_ALLOC_INTERNAL,
                         R_WM_COLORFMT_ARGB8888,
                         1,
                         LayerNumMax,
                         Width,
                         Height,
                         locWindows);
    
    /* Create the windows using the WM and enable the layers*/
    for (layerIndex = 0; layerIndex < LayerNumMax; layerIndex ++)
    {
        wm_err = R_WM_Test_CreateWindowSurface(DuUnit, &locWindows[layerIndex]);
        if (R_WM_ERR_OK != wm_err)
        {
            printf("[R_WM_Test_CreateWindowSurface] Failed to create window layer %d\n, WM Error = %d\n", layerIndex, wm_err);
            ret = 1;
            goto quit;
        }
        
        wm_err = loc_RenderToFb(DuUnit,&locWindows[layerIndex], (MyColours[layerIndex]));
        if (R_WM_ERR_OK != wm_err)
        { 
            printf("[Test_WindowSettings] Failed to Write to FB window layer %d\n, WM Error = %d\n", layerIndex, wm_err);
            ret = 1;
            goto quit;
        }
                
        wm_err = R_WM_WindowEnable(DuUnit, &locWindows[layerIndex]);
        if (R_WM_ERR_OK != wm_err)
        { 
            printf("[Test_WindowSettings] Failed to Enable window layer %d\n, WM Error = %d\n", layerIndex, wm_err);
            ret = 1;
            goto quit;
        }
    }
    printf("DOC VOC (success) test for DU%d.\n",DuUnit);
    ptr = doc_execute(DuUnit, Width, Height, 1, 0);
   if(ptr != NULL)
    {
        ret = 1;
    }
    ptr = doc_execute(DuUnit, Width, Height, 1, 1);
   if(ptr != NULL)
    {
        ret = 1;
    }


    printf("DOC VOC (failure) test for DU%d.\n",DuUnit);

    ptr = doc_execute(DuUnit, Width, Height, 0, 0);
    if(ptr != NULL)
    {
        ret = 1;
    }
    ptr = doc_execute(DuUnit, Width, Height, 0, 1);
    if(ptr != NULL)
    {
        ret = 1;

    }

    printf("DOC ACT Monitor success test for DU%d.\n", DuUnit);
    ptr = doc_execute_active(DuUnit, Width, Height, 1, 0);
    if(ptr != NULL)
    {
        ret = 1;
    }
    ptr = doc_execute_active(DuUnit, Width, Height, 1, 1);
    if(ptr != NULL)
    {
        ret = 1;
    }

    printf("DOC ACT Monitor failure test for DU%d.\n", DuUnit);
    ptr = doc_execute_active(DuUnit, Width, Height, 0, 0);
    if(ptr != NULL)
    {
        ret = 1;
    }
    ptr = doc_execute_active(DuUnit, Width, Height, 0, 1);
    if(ptr != NULL)
    {
        ret = 1;
    }

quit:
    for (layerIndex = 0; layerIndex < LayerNumMax; layerIndex ++)
    {
        wm_err = R_WM_Test_DeleteWindowSurface(DuUnit, &locWindows[layerIndex]);
    }
    free(locWindows);
    return ret;
}


/*******************************************************************************
  Function: loc_Test_DocParams
  
  This function test if the function R_WM_ScreenCmmSetProperty returns the expected errors
  when wrong input parameters are given.
  
*/
static uint32_t loc_Test_DocParams(void)
{
    uint32_t ret = 0;
    /* TO DO: implement the function parameter test for Discom Parameters*/
    return ret;
}

/*******************************************************************************
    Section: Global Functions
*/


/*******************************************************************************
    Function: R_WM_DocTest
    
    per default use DU 0
*/
uint32_t R_WM_DocTest(void) 
{
    r_wm_Error_t       wm_err = R_WM_ERR_OK;
    uint32_t           ret = 0;
    uint32_t           testRes = 0;
    uint32_t           i; 
    uint32_t           dispUnit   = LOC_DISPLAY;
    uint32_t           LayerNumMax;
    uint32_t           PitchMax;
    uint32_t           WidthMax;
    uint32_t           HeightMax;
    int32_t            vspUnit;
    int32_t            vspDuLayer;
    r_wm_OutColorFmt_t ColorFormat;
    
    
    /* Initialise the WM  */
    wm_err = R_WM_Test_InitWM(dispUnit,
                              &LayerNumMax,
                              &PitchMax,
                              &WidthMax,
                              &HeightMax,
                              &ColorFormat);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[R_WM_Test_Windows] Failed to Init WM Dev %d\n, WM Error = %d\n", dispUnit, wm_err);
        ret = 1;
        goto quit;
    }
    
 
    /* Set screen, light green ;) */
    wm_err = R_WM_Test_InitScreen(dispUnit, 0,55,0); 

    if (R_WM_ERR_OK != wm_err)
    {
        printf("[R_WM_Test_Windows] Failed to setup Screen %d\n, WM Error = %d\n", dispUnit, wm_err);
        ret = 1;
        goto DisableWm;
    }
    
    /* get information on the display */
    wm_err = R_WM_DevInfoGet(dispUnit,
                             &LayerNumMax,
                             &PitchMax,
                             &WidthMax,
                             &HeightMax,
                             &ColorFormat,
                             &vspUnit,
                             &vspDuLayer);

    
    wm_err = R_WM_DevEventRegister(dispUnit, R_WM_EVENT_VBLANK, 0);
    
    
    
    CreateProtectedTask(100, (Address)loc_ErrTask0_chk, 0x2000, "Doc0_chk", &children[0][0]);
    CreateProtectedTask(100, (Address)loc_ErrTask0_mon, 0x2000, "Doc0_mon", &children[0][1]);
    CreateProtectedTask(100, (Address)loc_ErrTask1_chk, 0x2000, "Doc1_chk", &children[1][0]);
    CreateProtectedTask(100, (Address)loc_ErrTask1_mon, 0x2000, "Doc1_mon", &children[1][1]);
    CreateProtectedTask(100, (Address)loc_ErrTask2_chk, 0x2000, "Doc2_chk", &children[2][0]);
    CreateProtectedTask(100, (Address)loc_ErrTask2_mon, 0x2000, "Doc2_mon", &children[2][1]);
#ifdef RCAR_H3
    CreateProtectedTask(100, (Address)loc_ErrTask3_chk, 0x2000, "Doc3_chk", &children[3][0]);
    CreateProtectedTask(100, (Address)loc_ErrTask3_mon, 0x2000, "Doc3_mon", &children[3][1]);
#endif

    wm_err = R_WM_ScreenDocIntRegister(dispUnit, R_WM_DOC_INTC_VOC);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to register VOC interrupt, WM Error = %d\n", wm_err);
        ret++;
    }
    wm_err = R_WM_ScreenDocIntRegister(dispUnit, R_WM_DOC_INTC_ACTMON);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[doc_execute] Failed to register ACT interrupt, WM Error = %d\n", wm_err);
        ret++;
    }


    RunTask(children[dispUnit][0]);
    RunTask(children[dispUnit][1]);

#ifdef RCAR_H3
//    CreateProtectedTask(100, (Address)loc_ErrTask3_chk, 0x2000, "Doc3_chk", &children[0][0]);
//    CreateProtectedTask(100, (Address)loc_ErrTask3_mon, 0x2000, "Doc3_mon", &children[0][0]);
//    RunTask(children[3][0]);
//    RunTask(children[3][1]);
#endif
    


    /* Test the WM Windows functions and their parameters */
    printf("\t[WM TEST]: Window functions parameter tests: \n");
    ret = loc_Test_DocParams();
    if(ret)
    {
        printf("\t\tFailed\n\n");
        testRes++; /* Failed */
    } else {
        printf("\t\tSuccess\n\n");
    }
    printf("\t[WM TEST]: Properties tests: \n");
    ret = loc_Test_Doc(dispUnit, LayerNumMax, WidthMax, HeightMax);
    if(ret)
    {
        printf("\t\tFailed\n\n");
        testRes++; /* Failed */
    } else {
        printf("\t\tSuccess\n\n");
    }

    for (i = 0; i < R_WM_DOC_NUM; i++)
    {
        CloseProtectedTask(children[i][0]);
        CloseProtectedTask(children[i][1]);
    }
    
    wm_err = R_WM_ScreenDocDeInit(dispUnit);
    if (R_WM_ERR_OK != wm_err)
    {
        printf("[discom_execute] Failed to DeInit Discom, WM Error = %d\n", wm_err);
        ret = 1;
    }

    /* Disable Screen */
    wm_err |= R_WM_Test_DeInitScreen(dispUnit);
    
DisableWm:
    /* De - initialise the WM */
    wm_err |= R_WM_Test_DeInitWM(dispUnit);
    wm_err |= R_WM_DevDeinit(R_WM_DEV_TEXTURE);

quit:
    return ret;
}
