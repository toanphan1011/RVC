#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>

#define ERROR_WORD_EXIST     1
#define ERROR_NONE		     0
#define ERROR_WORD_NOT_EXSIT 2
#define HASH_SIZE 63
struct Word {
          unsigned char *word;  // word name
          unsigned long offset; // offset of the meaning of the word in the dictionary file
          struct Word *next;    // pointer to next word object
      };


struct Word* hashdict[HASH_SIZE];

struct Word* create_word (const char *w, unsigned long off)
{
	struct Word* fresh_word;
	fresh_word = (struct Word*) malloc(sizeof(struct Word));
	fresh_word->word = (unsigned char*) malloc(50*sizeof(unsigned char));	
	strcpy((char*)fresh_word->word, w );
	fresh_word->offset = off;
	fresh_word-> next = NULL;
	return fresh_word;
}

int hash_word (unsigned char *w)
{ 
	if(('A' < *w)&&(*w < 'Z'))
		return (*w - 'A');
	else if(('a' < *w)&&(*w < 'z'))
		return (*w - 'a' + 25);
	else if(('0' < *w)&&(*w < '9'))
		return (*w - '0' + 52 );
	else
		return 62;
}


int insert_word(struct Word **hd, struct Word *wobject)
{
	struct Word *current= NULL;
	int i;

	i = hash_word(wobject->word);
	current= hd[i];
	if(current->word == NULL)
	{
		wobject->next = NULL;
		hd[i] = wobject;
		return ERROR_NONE;
	}
	else if(current->next == NULL)
	{
		if(current->word == wobject->word)
			return ERROR_WORD_EXIST;
		wobject->next = NULL;
	    current->next= wobject;
		return ERROR_NONE;
	}
	else
	{

		while(current->next != NULL)
		{
			current= current->next;
		}
			wobject->next = NULL;
			current->next = wobject;
			return ERROR_NONE;	
		}
}


struct Word* search_word (struct Word **hd, unsigned char *word)
{
	int i=0;
	struct Word *current;
	i = hash_word(word);
	current = hd[i];
	if(current->next == NULL)
	{
		if(current->offset == 0)
			return NULL;
		if(strcmp((const char*)current->word,(const char*)word)==0)//*current->word == *word)
		{
			return current;
		}
		else
			return NULL;
	}
	while(current->next != NULL)
	{
		if(strcmp((const char*)current->word,(const char*)word)==0)//*current->word == *word)
		{
			return current;
		}
		current = current->next;
	}
}

int get_meaning (unsigned char *buf, struct Word* wobject, FILE *dict_file)
{
	int i;
	if(dict_file == NULL)
		return 0;
	fseek(dict_file, wobject->offset, 0);
	i = 0;
	buf[i] = fgetc(dict_file);
	while((buf[i] != '#')&&(buf[i] != 255))
	{
		buf[++i] = fgetc(dict_file);
	}
	buf[i-1] = NULL;
	if(buf[0] == NULL)
		return ERROR_WORD_NOT_EXSIT;
	else
		return ERROR_NONE;
}

int scan_file(FILE *dict_file)
{
	struct Word *hash;
	unsigned long offs;
	char temp;
	char *word_s;
	int i;
	word_s = (char*)malloc(500*sizeof(char));
	if(dict_file == NULL)
		return 0;
	rewind(dict_file);
	
	temp = fgetc(dict_file);
	while(temp != EOF)
	{
		if(temp == '#')
		{
			fgets(word_s,250, dict_file);
			for(i=0;word_s[i] != NULL;i++);
			word_s[i-1] = NULL;

			offs = ftell(dict_file)+1;	//offset
			hash = create_word(word_s, offs);
			insert_word(hashdict,hash);
		}	
	temp = fgetc(dict_file);
	}
	return 1;
}

int search_meaning_word(struct Word **hd, unsigned char *w_search, FILE *dict_file, unsigned char *meaning)
{
	struct Word *result;
	int i;

	if(dict_file == NULL)
		return 0;
	result = search_word(hd, w_search);
	if(result != NULL)
		i = get_meaning(meaning, result, dict_file);
	else
		i = 0;
	return i;
}

void main(void)
{
		FILE *d_file ;
	unsigned char *w_search, *meaning, chrt;
	int i;
	w_search = (unsigned char*)malloc(50*sizeof(unsigned char));
	meaning = (unsigned char*)malloc(200*sizeof(unsigned char));

	d_file = fopen("dictionary.txt","r");

	for(i=0;i<63;i++)
	{
		hashdict[i] = (struct Word*) malloc(200*sizeof(struct Word));
		hashdict[i]->word = (unsigned char*) malloc(sizeof(unsigned char));
		hashdict[i]->word = (unsigned char*)'\0';
		hashdict[i]->next = NULL;
		hashdict[i]->offset = 0;
	}
	scan_file(d_file);

	while(1)
	{
		printf("Input word:");
		gets((char*)w_search);
		if(*w_search == (unsigned char) '`')
			break;
		i = search_meaning_word(hashdict, w_search, d_file, meaning);
		if(i==0)
			printf("%s\n\n", meaning);
		else 
			printf("Search again!\n");
	}
	getch();
}