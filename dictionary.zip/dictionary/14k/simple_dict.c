// put the source code of main program here.
// reading file
// saving to link list list
// get command from user, and display the result

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

int main(int argc, char *argv[]){

	struct Word* hashdict[HASH_SIZE];
	int i;
	char ch;
	unsigned char buf[100000];
	unsigned char w[1000];
	unsigned long off;
	struct Word *wobject;
	FILE *fp;
	
	// Allocate a hashdict
	for(i=0;i<63;i++){
		hashdict[i] = (struct Word*) malloc(sizeof(struct Word));
		hashdict[i]->word = (unsigned char *) malloc(sizeof(unsigned char ));
		hashdict[i]->offset = 0;
		hashdict[i]->next = NULL;
		
	}
	// Check file dictionary.txt can open or not
	if((fp=fopen("dictionary.txt","r"))==NULL){
		printf("Can not open file:\n");
		exit(0);
	}
	
	//Scan the dictionary data file
	do{
		ch = getc(fp);
		if(ch=='#'){
			fgets(w,sizeof(w),fp);
			//remove the newline character LF, CR
			i = strlen(w);
			while(w[i - 1] == 10 || w[i - 1] == 13){
			
				w[i - 1] = '\0';
				i = strlen(w);
			}
			off = ftell(fp);
			wobject = create_word(w,off);
			if(insert_word(hashdict,wobject)==0){
				printf("This word is exit.\n");
			}
			
		}
	}while(ch!=EOF);
	
	// Searching
	if(argc == 2){
		
		sprintf(w, "%s", argv[1]); // Input the word by user
		wobject = search_word(hashdict,w); 
		if(wobject==NULL){
			printf("Can not find %s\n",w);
		}
		else
		{
			if(get_meaning(buf,wobject,fp)==1){
				printf("%s",buf);
			}else{
			printf("Can not find meaning of %s\n",w);
			}
		}
	}else{
		if(argc==1){ // don't have any agrement
			printf("Error: Please Input parameter\n");
		}else{
			printf("Error: Please Input 1 parameter only\n");
		}
	}
	fclose(fp);
	
	
	return 0;
}
