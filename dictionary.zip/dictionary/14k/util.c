// put the implementation of utility functions here

#include"util.h"

struct Word* search_word (struct Word **hd, unsigned char *w)
{
	int x;
	char *c;
	c = w;
	x = hash_word(c); // select a position in the hash table
	struct Word* temp;
	temp = (struct Word*) malloc(sizeof(struct Word));
	temp = hd[x]; 
	
	// Search a word in hash table. If this word exist, return this word.
	while(temp->next!=NULL){
		if(strcmp(temp->word,w)==0){ 
			return temp;
		}
		temp=temp->next;
	}

	return NULL;
}
int get_meaning (unsigned char *buf, struct Word* wobject, FILE *dict_file){
	
	unsigned char temp[100000];
	int size = 0; 
	
	fseek(dict_file, wobject->offset, SEEK_SET); //move pointer to the offset of the meaning of word
	while((fgets(temp, sizeof(temp), dict_file) != NULL) && (temp[0] != '#')){	
		//copy the line value into buf		
		size += sprintf(buf + size,temp);
	}
	if(size > 0){
		//return true if no error
		return 1; // TRUE
		
	}
	//error occur or the content not find
	return 0; // FLASE
	
	
	
}