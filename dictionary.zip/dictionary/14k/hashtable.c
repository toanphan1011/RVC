// put the implementation of hash table here

#include"hashtable.h" 
#include <stdio.h>
#include <stdlib.h>

struct Word* create_word (const char *w,unsigned long off)
{
	struct Word *pW;
	pW = (struct Word*) malloc(sizeof(struct Word)); // Allocate memory for the word object
	pW->word = (unsigned char *) malloc(sizeof(unsigned char )*40); // Allocate memory to store the word
	strcpy(pW->word,w);  //copy the parameter "w" to "word" field
	pW->offset = off; // Copy the parameter off to offset field
	pW->next = NULL; // the next wobject is NULL
	return pW;
}

int hash_word (unsigned char *w)
{
	char c = w[0];
	
	if(c >= 'A' && c<='Z'){ 
		return (c-48);
	}
	if(c >= 'a' && c<='z'){ 
		return (c-71);
	}
	if(c >= '0' && c<='9'){
		return (c+4);
	}
	return 62;
	
	
	

}

int insert_word (struct Word **hd, struct Word *wobject)
{
	int x;
	char *c;
	c = wobject->word;
	x = hash_word(c); // select a position in the hash table
	struct Word* temp;
	temp = hd[x];
	
	while(temp->next!=NULL){	
		if(strcmp(temp->word, wobject->word)==0){ // if the word has already existed in the hash table
			return 0; // false
		}
		temp=temp->next;
			
	}
	wobject->next = hd[x];
	hd[x]=wobject;
	return 1; // true
	
	
	
}

