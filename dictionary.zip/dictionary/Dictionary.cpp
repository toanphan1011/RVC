// Big_excerise.cpp : Defines the entry point for the console application.
#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>


#define		TRUE	1
#define		FALSE	0
#define     HASH_SIZE 63

struct Word 
{
	unsigned char *word;  // word name
	unsigned long offset; // offset of the meaning of the word in the dictionary file
	struct Word *next;    // pointer to next word object
};


struct Word* hashdict[HASH_SIZE];



struct Word* create_word (const char *w, unsigned long off)
{
	struct Word* create;
	create = (struct Word*) malloc(sizeof(struct Word));
	create->word = (unsigned char*) malloc(50*sizeof(unsigned char));	
	strcpy((char*)create->word, w );
	create->offset = off;
	create-> next = NULL;
	return create;
}

int hash_word (unsigned char *w)
{ 
	if((0x40 < *w)&&(*w < 0x5b))
		return (*w - 0x41);
	if((0x60 < *w)&&(*w < 0x7b))
		return (*w - 0x61 + 25);
	if((0x2f < *w)&&(*w < 0x40))
		return (*w - 0x30 + 52 );
	else
		return 62;
}

int insert_word (struct Word **hd, struct Word *wobject)
{
	struct Word *temp;
	int i;

	i = hash_word (wobject->word);
	temp = hd[i];
	if (hd[i]->word == NULL )
	{
		hd[i] = wobject;
		hd[i]->next = NULL;
		return TRUE;
	}
	else 
	{
		while (temp->next != NULL)
		{	
			temp = temp->next;
		}
		if (temp->word == wobject->word)
			return FALSE;
		else
		{
			temp->next = wobject;
			wobject->next = NULL;
			return TRUE;
		}		
	}
}	

struct Word* search_word (struct Word **hd, unsigned char *word)
{
	int i,j = 0;
	struct Word *temp;
	struct Word *te;

	i = hash_word (word);
	temp = hd[i];
	if (temp->next == NULL)
	{
			if (temp->offset == 0)
				return NULL;
			else 
			{						
				j = 0;
				while (temp->word[j] == word[j])
				{
					j++;
				}
				if (temp->word[j] == 10)
				{
					return temp;
				}
				else 
					return NULL;
			}
	}
	else 
	{
		while ((*temp->word != NULL)&&(temp->next != NULL))
			{					
				j = 0;
				while (temp->word[j] == word[j])
				{
					j++;
				}
				if (temp->word[j] != 10)
				{		
					temp = temp->next;
				}
				else 		
					return temp;				
			}
	}
	j=0;
	while (temp->word[j] == word[j])
		{
			j++;
		}
		if (temp->word[j] == 10)
		{
			return temp;
		}

	return NULL;
}


int get_meaning (unsigned char *buf, struct Word* wobject, FILE *dict_file)
{		
	int i = 0;

	fseek(dict_file,wobject->offset,0);	
	i = 0;
	buf[0] = fgetc(dict_file);
	while ((buf[i] != '#')&& (buf[i]!=255))
	{
		i++;
		buf[i] = fgetc(dict_file);	
	}	
	buf[i-1]=NULL;
	i = 1;
	return i;
}

struct Word* scan_file(FILE *dict_file)
{	
	struct Word* file;
	long b;
	char a;
	char *scan;

	scan =(char*) malloc(sizeof(char));
	fseek(dict_file,0,0);
	a =  fgetc(dict_file);
	while (a != EOF)
	{ 	
		if (a == '#')
		{
			fgets(scan, 2000,dict_file);
			b = ftell(dict_file) + 1;
			file = create_word (scan, b );
			insert_word (hashdict,file); 
		}
		a = fgetc(dict_file);	
	}
	return file;
}

int start_search (struct Word **hd, unsigned char *input,unsigned char* buffer, FILE *dict_file)
{
	int i;
	struct Word* search;

	search = search_word (hd, input );
	if (search != NULL)
		{
		i = get_meaning (buffer, search, dict_file);
		}
	else 
		i = 0;	
	return i;
}


void main(void)
{
	FILE *dict_file;
	dict_file = fopen("dictionary.txt", "r");
	int i,k;	
	char *input_keyboard;
	input_keyboard = ( char*) malloc(50*sizeof( char));
	unsigned char *buffer;
	buffer = (unsigned char*) malloc(100*sizeof(unsigned char));

	for (k = 0; k<63; k++)
	{
		hashdict[k] = (struct Word*) malloc(sizeof(struct Word));
		hashdict[k]->word = (unsigned char*) malloc(sizeof(unsigned char));

		hashdict[k]->word = (unsigned char*)'\0';
		hashdict[k]->next = NULL;
		hashdict[k]->offset = 0;
	}
	scan_file(dict_file);
	while(1)
	{
		printf("Input: ");
		gets(input_keyboard);
		i = start_search (hashdict,(unsigned char*)input_keyboard, buffer, dict_file);	
		if (i == 1)
		{
			printf("%s \n", buffer);
		}
		else 
		{
			printf( "Can not find %s \n" , input_keyboard);
		}
	}

}