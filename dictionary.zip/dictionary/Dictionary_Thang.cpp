// Test.cpp : Defines the entry point for the console application.
//

#include <stdafx.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>

#define HASH_SIZE 63
struct Word {
          unsigned char *word;  // word name
          unsigned long offset; // offset of the meaning of the word in the dictionary file
          struct Word *next;    // pointer to next word object
      };


struct Word* hashdict[HASH_SIZE];

struct Word* create_word (const char *w, unsigned long off)
{
	struct Word *Cre;
	Cre = (struct Word*) malloc(50*sizeof(struct Word));
	Cre->word = (unsigned char*) malloc(50*sizeof(unsigned char));
	strcpy((char*)Cre->word,w);
	Cre->offset = off;
	Cre->next = (struct Word *)NULL;
	return Cre;
}

int hash_word (unsigned char *w)
{
	if((0x40 < *w)&&(*w < 0x5b))
		return (*w - 0x41);
	if((0x60 < *w)&&(*w < 0x7b))
		return (*w - 0x61 + 25);
	if((0x2f < *w)&&(*w < 0x40))
		return (*w - 0x30 + 52 );
	return 62;

}


int insert_word(struct Word **hd, struct Word *wobject)
{
	
	int i, j, hp;
	i=0;
	j=0;
	Word *temp1;
	hp = hash_word(wobject->word);



		temp1= hd[hp];
		if(temp1->word == NULL)
		{
			wobject->next = NULL;
			hd[hp] = wobject;
			return 1;
		}
		if(temp1->next == NULL)
				{
					if(temp1->word == wobject->word)
						return 0;
					wobject->next = NULL;
					hd[hp]->next = wobject;
					return 1;
				}
		else
		{

				while(temp1->next != NULL)
				{
					temp1= temp1->next;
				}
				wobject->next = NULL;
				temp1->next = wobject;
				return 1;

			
			
		}

	
}


struct Word* search_word (struct Word **hd, unsigned char *word)
{
	int i=0;
	struct Word *temp;
	i = hash_word(word);
	temp = hd[i];
	if(temp->next == NULL)
	{
		if(temp->offset == 0)
			return NULL;
		if(strcmp((const char*)temp->word,(const char*)word)==0)//*temp->word == *word)
		{
			return hd[i];
		}
		else
			return NULL;
	}
	while(temp->next != NULL)
	{
		if(strcmp((const char*)temp->word,(const char*)word)==0)//*temp->word == *word)
		{
			return temp;
		}
		temp = temp->next;
	}
	if(strcmp((const char*)temp->word,(const char*)word)==0)//*temp->word == *word)
		{
			return temp;
		}
	return NULL;
}

int get_meaning (unsigned char *buf, struct Word* wobject, FILE *dict_file)
{
	int i;
	if(dict_file == NULL)
		return 0;
	fseek(dict_file, wobject->offset, 0);
	i = 0;
	buf[i] = fgetc(dict_file); // fgets((char*)buf, 500, dict_file);
	while((buf[i] != '#')&&(buf[i] != 255))
	{
		buf[++i] = fgetc(dict_file);
	}
	buf[i-1] = NULL;
	if(buf[0] == NULL)
		return 0;
	else
		return 1;
}

int scan_file(FILE *dict_file)
{
	struct Word *hash;
	unsigned long ofs;
	char temp;
	char	*word_s;
	int i;
	word_s = (char*)malloc(500*sizeof(char));
	if(dict_file == NULL)
		return 0;
	rewind(dict_file); // fseek(dict_file, 0, 0);
	
	temp = fgetc(dict_file);
	while(temp != EOF)
	{
		if(temp == '#')
		{
			fgets(word_s,250, dict_file);
			for(i=0;word_s[i] != NULL;i++);
			word_s[i-1] = NULL;

			ofs = ftell(dict_file)+1;	//offset
			hash = create_word(word_s, ofs);
			insert_word(hashdict,hash);
		}	
	temp = fgetc(dict_file);
	}
	return 1;
}

int search_meaning_word(struct Word **hd, unsigned char *w_search, FILE *dict_file, unsigned char *meaning)
{
	Word *result;
	int i;

	if(dict_file == NULL)
		return 0;
	result = search_word(hd, w_search);
	if(result != NULL)
		i = get_meaning(meaning, result, dict_file);
	else
		i = 0;
	return i;
}

void main(void)
{
	FILE *d_file ;
	d_file = fopen("dictionary.txt","r");
	unsigned char *w_search, *meaning, chrt;
	int i;
	w_search = (unsigned char*)malloc(40*sizeof(unsigned char));
	meaning = (unsigned char*)malloc(50*sizeof(unsigned char));
	for(i=0;i<63;i++)
	{
		hashdict[i] = (struct Word*) malloc(500*sizeof(struct Word));
		hashdict[i]->word = (unsigned char*) malloc(sizeof(unsigned char));
		hashdict[i]->word = (unsigned char*)'\0';
		hashdict[i]->next = NULL;
		hashdict[i]->offset = 0;
	}
	scan_file(d_file);

	while(1)
	{
		printf("Input word(press ` to exit):");
		gets((char*)w_search);
		if(*w_search == (unsigned char) '`')
			break;
		i = search_meaning_word(hashdict, w_search, d_file, meaning);
		if(i)
			printf("%s: \n\t%s\n",w_search,meaning);
		else
			printf("%s:\tWord cannot find! Search again!\n",w_search);
	}
	getch();
}
